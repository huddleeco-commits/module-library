import React, { useState, useEffect } from 'react';

const History = () => {
  const [activeTab, setActiveTab] = useState('All');
  const [transactions, setTransactions] = useState([]);
  const [filteredTransactions, setFilteredTransactions] = useState([]);

  useEffect(() => {
    fetchTransactions();
  }, []);

  useEffect(() => {
    filterTransactions();
  }, [activeTab, transactions]);

  const fetchTransactions = async () => {
    try {
      const response = await fetch('/api/transactions');
      const data = await response.json();
      setTransactions(data);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  };

  const filterTransactions = () => {
    if (activeTab === 'All') {
      setFilteredTransactions(transactions);
    } else if (activeTab === 'Earned') {
      setFilteredTransactions(transactions.filter(t => t.type === 'earned'));
    } else if (activeTab === 'Spent') {
      setFilteredTransactions(transactions.filter(t => t.type === 'spent'));
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const tabs = ['All', 'Earned', 'Spent'];

  return (
    <div className="history-container">
      <div className="ios-segmented-control">
        {tabs.map(tab => (
          <button
            key={tab}
            className={activeTab === tab ? 'active' : ''}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="transactions-list">
        {filteredTransactions.map(transaction => (
          <div key={transaction.id} className="ios-list-row">
            <div className="transaction-info">
              <div className="transaction-title">{transaction.description}</div>
              <div className="transaction-date">{formatDate(transaction.created_at)}</div>
            </div>
            <div className={`transaction-points ${transaction.type}`}>
              {transaction.type === 'earned' ? '+' : '-'}{transaction.points} points
            </div>
          </div>
        ))}
        
        {filteredTransactions.length === 0 && (
          <div className="empty-state">
            <p>No transactions found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default History;