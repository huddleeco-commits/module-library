import React from 'react';

function Dashboard({ user }) {
  const getTierColor = (tier) => {
    switch (tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const getTierProgress = (points, tier) => {
    const thresholds = { Bronze: 0, Silver: 1000, Gold: 5000, Platinum: 10000 };
    const nextTierThreshold = {
      Bronze: 1000,
      Silver: 5000,
      Gold: 10000,
      Platinum: 10000
    };
    
    const current = points - thresholds[tier];
    const needed = nextTierThreshold[tier] - thresholds[tier];
    
    return tier === 'Platinum' ? 100 : Math.min((current / needed) * 100, 100);
  };

  const progress = getTierProgress(user.points, user.tier);
  const nextTier = {
    Bronze: 'Silver',
    Silver: 'Gold',
    Gold: 'Platinum',
    Platinum: 'Platinum'
  }[user.tier];

  return (
    <div className="ios-card" style={{ textAlign: 'center', marginBottom: '20px' }}>
      <h2>Welcome back, {user.name}</h2>
      
      <div style={{ margin: '24px 0' }}>
        <div style={{ fontSize: '48px', fontWeight: 'bold', color: '#007AFF', marginBottom: '8px' }}>
          {user.points.toLocaleString()}
        </div>
        <div style={{ fontSize: '16px', color: '#666' }}>points</div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '20px' }}>
        <span>Current Tier:</span>
        <span 
          className="ios-badge" 
          style={{ backgroundColor: getTierColor(user.tier), color: 'white' }}
        >
          {user.tier}
        </span>
      </div>

      {user.tier !== 'Platinum' && (
        <div style={{ margin: '16px 0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ fontSize: '14px', color: '#666' }}>Progress to {nextTier}</span>
            <span style={{ fontSize: '14px', color: '#666' }}>{Math.round(progress)}%</span>
          </div>
          <div style={{ 
            width: '100%', 
            height: '8px', 
            backgroundColor: '#E5E5EA', 
            borderRadius: '4px',
            overflow: 'hidden'
          }}>
            <div style={{
              width: `${progress}%`,
              height: '100%',
              backgroundColor: getTierColor(nextTier),
              transition: 'width 0.3s ease'
            }} />
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;