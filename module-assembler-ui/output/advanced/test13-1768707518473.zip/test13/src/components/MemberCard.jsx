import React from 'react';

function MemberCard({ user }) {
  const getTierColor = (tier) => {
    switch (tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const generateQRCode = (userId) => {
    return `data:image/svg+xml;base64,${btoa(`
      <svg width="80" height="80" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="80" fill="white"/>
        <g fill="black">
          <rect x="10" y="10" width="60" height="60" fill="none" stroke="black" stroke-width="2"/>
          <rect x="15" y="15" width="4" height="4"/>
          <rect x="25" y="15" width="4" height="4"/>
          <rect x="35" y="15" width="4" height="4"/>
          <rect x="45" y="15" width="4" height="4"/>
          <rect x="55" y="15" width="4" height="4"/>
          <rect x="15" y="25" width="4" height="4"/>
          <rect x="35" y="25" width="4" height="4"/>
          <rect x="55" y="25" width="4" height="4"/>
          <rect x="15" y="35" width="4" height="4"/>
          <rect x="25" y="35" width="4" height="4"/>
          <rect x="45" y="35" width="4" height="4"/>
          <rect x="15" y="45" width="4" height="4"/>
          <rect x="35" y="45" width="4" height="4"/>
          <rect x="55" y="45" width="4" height="4"/>
          <rect x="15" y="55" width="4" height="4"/>
          <rect x="25" y="55" width="4" height="4"/>
          <rect x="35" y="55" width="4" height="4"/>
          <rect x="45" y="55" width="4" height="4"/>
          <rect x="55" y="55" width="4" height="4"/>
        </g>
      </svg>
    `)}`;
  };

  return (
    <div 
      className="ios-card" 
      style={{
        background: `linear-gradient(135deg, ${getTierColor(user.tier)}22, ${getTierColor(user.tier)}11)`,
        border: `1px solid ${getTierColor(user.tier)}33`,
        position: 'relative',
        overflow: 'hidden',
        minHeight: '200px'
      }}
    >
      <div style={{
        position: 'absolute',
        top: '16px',
        right: '16px',
        background: getTierColor(user.tier),
        color: 'white',
        padding: '4px 12px',
        borderRadius: '20px',
        fontSize: '12px',
        fontWeight: 'bold'
      }}>
        {user.tier}
      </div>

      <div style={{ padding: '20px' }}>
        <h3 style={{ margin: '0 0 8px 0', fontSize: '18px' }}>Member Card</h3>
        <p style={{ margin: '0 0 16px 0', color: '#666', fontSize: '14px' }}>
          {user.name}
        </p>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: getTierColor(user.tier) }}>
              {user.points.toLocaleString()}
            </div>
            <div style={{ fontSize: '12px', color: '#666' }}>Points</div>
            <div style={{ fontSize: '12px', color: '#666', marginTop: '8px' }}>
              ID: {user.id.toString().padStart(6, '0')}
            </div>
          </div>
          
          <div style={{ textAlign: 'center' }}>
            <img 
              src={generateQRCode(user.id)} 
              alt="Member QR Code" 
              style={{ width: '80px', height: '80px', border: '1px solid #ddd' }}
            />
            <div style={{ fontSize: '10px', color: '#666', marginTop: '4px' }}>Scan to redeem</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MemberCard;