import React, { useState, useEffect } from 'react';

const Rewards = () => {
  const [rewards, setRewards] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedReward, setSelectedReward] = useState(null);
  const [userPoints, setUserPoints] = useState(0);

  useEffect(() => {
    fetchRewards();
    fetchUserPoints();
  }, []);

  const fetchRewards = async () => {
    try {
      const response = await fetch('/api/rewards');
      const data = await response.json();
      setRewards(data);
    } catch (error) {
      console.error('Error fetching rewards:', error);
    }
  };

  const fetchUserPoints = async () => {
    try {
      const response = await fetch('/api/user/points');
      const data = await response.json();
      setUserPoints(data.points);
    } catch (error) {
      console.error('Error fetching points:', error);
    }
  };

  const handleRedeem = (reward) => {
    setSelectedReward(reward);
    setShowModal(true);
  };

  const confirmRedeem = async () => {
    try {
      const response = await fetch('/api/rewards/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rewardId: selectedReward.id })
      });
      if (response.ok) {
        setUserPoints(prev => prev - selectedReward.points_cost);
        setShowModal(false);
        setSelectedReward(null);
      }
    } catch (error) {
      console.error('Error redeeming reward:', error);
    }
  };

  return (
    <div className="rewards-container">
      <div className="points-balance">
        <h2>Available Points: {userPoints}</h2>
      </div>
      
      <div className="rewards-grid">
        {rewards.map(reward => (
          <div key={reward.id} className="ios-card">
            <img src={reward.image_url} alt={reward.name} className="reward-image" />
            <h3>{reward.name}</h3>
            <p>{reward.description}</p>
            <div className="reward-cost">{reward.points_cost} points</div>
            <button 
              className="ios-button-primary"
              onClick={() => handleRedeem(reward)}
              disabled={userPoints < reward.points_cost}
            >
              Redeem
            </button>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="ios-modal-sheet">
          <div className="modal-content">
            <h3>Confirm Redemption</h3>
            <p>Redeem {selectedReward?.name} for {selectedReward?.points_cost} points?</p>
            <div className="modal-actions">
              <button className="ios-button-primary" onClick={confirmRedeem}>
                Confirm
              </button>
              <button onClick={() => setShowModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rewards;