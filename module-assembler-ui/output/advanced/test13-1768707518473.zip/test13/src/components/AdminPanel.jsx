import React, { useState, useEffect } from 'react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [pointsAmount, setPointsAmount] = useState('');
  const [stats, setStats] = useState({ totalCustomers: 0, totalPoints: 0, avgPoints: 0 });

  useEffect(() => {
    fetchCustomers();
    fetchStats();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch('/api/customers');
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const addPoints = async () => {
    if (!selectedCustomer || !pointsAmount) return;
    try {
      await fetch('/api/add-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId: selectedCustomer, points: parseInt(pointsAmount) })
      });
      setPointsAmount('');
      setSelectedCustomer('');
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error adding points:', error);
    }
  };

  const filteredCustomers = customers.filter(customer =>
    customer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderCustomers = () => (
    <div className="ios-card">
      <h2>Customers</h2>
      <input
        type="text"
        className="ios-input"
        placeholder="Search customers..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <div className="customer-list">
        {filteredCustomers.map(customer => (
          <div key={customer.id} className="ios-list-row">
            <div>
              <strong>{customer.name}</strong>
              <div className="customer-email">{customer.email}</div>
            </div>
            <div className="customer-points">
              {customer.points} points
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAddPoints = () => (
    <div className="ios-card">
      <h2>Add Points</h2>
      <div className="form-group">
        <label>Select Customer</label>
        <select
          className="ios-input"
          value={selectedCustomer}
          onChange={(e) => setSelectedCustomer(e.target.value)}
        >
          <option value="">Choose customer...</option>
          {customers.map(customer => (
            <option key={customer.id} value={customer.id}>
              {customer.name} - {customer.email}
            </option>
          ))}
        </select>
      </div>
      <div className="form-group">
        <label>Points Amount</label>
        <input
          type="number"
          className="ios-input"
          placeholder="Enter points"
          value={pointsAmount}
          onChange={(e) => setPointsAmount(e.target.value)}
        />
      </div>
      <button
        className="ios-button-primary"
        onClick={addPoints}
        disabled={!selectedCustomer || !pointsAmount}
      >
        Add Points
      </button>
    </div>
  );

  const renderStats = () => (
    <div className="ios-card">
      <h2>Statistics</h2>
      <div className="stats-grid">
        <div className="stat-item">
          <div className="stat-value">{stats.totalCustomers}</div>
          <div className="stat-label">Total Customers</div>
        </div>
        <div className="stat-item">
          <div className="stat-value">{stats.totalPoints}</div>
          <div className="stat-label">Total Points</div>
        </div>
        <div className="stat-item">
          <div className="stat-value">{stats.avgPoints}</div>
          <div className="stat-label">Average Points</div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="admin-panel">
      <h1>Loyalty Program Admin</h1>
      
      <div className="ios-segmented-control">
        <button
          className={activeTab === 'customers' ? 'active' : ''}
          onClick={() => setActiveTab('customers')}
        >
          Customers
        </button>
        <button
          className={activeTab === 'addPoints' ? 'active' : ''}
          onClick={() => setActiveTab('addPoints')}
        >
          Add Points
        </button>
        <button
          className={activeTab === 'stats' ? 'active' : ''}
          onClick={() => setActiveTab('stats')}
        >
          Statistics
        </button>
      </div>

      <div className="tab-content">
        {activeTab === 'customers' && renderCustomers()}
        {activeTab === 'addPoints' && renderAddPoints()}
        {activeTab === 'stats' && renderStats()}
      </div>

      <style jsx>{`
        .admin-panel {
          max-width: 1200px;
          margin: 0 auto;
          padding: 20px;
        }
        .tab-content {
          margin-top: 20px;
        }
        .customer-list {
          margin-top: 15px;
        }
        .customer-email {
          color: #666;
          font-size: 14px;
        }
        .customer-points {
          font-weight: 600;
          color: #007AFF;
        }
        .form-group {
          margin-bottom: 15px;
        }
        .form-group label {
          display: block;
          margin-bottom: 5px;
          font-weight: 500;
        }
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
          margin-top: 15px;
        }
        .stat-item {
          text-align: center;
          padding: 20px;
          background: #F2F2F7;
          border-radius: 12px;
        }
        .stat-value {
          font-size: 2em;
          font-weight: 600;
          color: #007AFF;
        }
        .stat-label {
          margin-top: 5px;
          color: #666;
        }
      `}</style>
    </div>
  );
};

export default AdminPanel;