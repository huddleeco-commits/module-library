import React from 'react';

const Profile = () => {
  const user = {
    name: 'John Doe',
    email: 'john.doe@email.com',
    tier: 'Gold',
    lifetimePoints: 2840,
    referralCode: 'JOHN2024'
  };

  const handleShare = () => {
    navigator.share({
      title: 'Join me on this loyalty app!',
      text: `Use my referral code: ${user.referralCode}`
    });
  };

  return (
    <div className="profile-page">
      <div className="ios-card">
        <div className="profile-header">
          <div className="avatar">
            {user.name.split(' ').map(n => n[0]).join('')}
          </div>
          <h2>{user.name}</h2>
          <span className="ios-badge ios-badge-gold">{user.tier}</span>
        </div>
      </div>
      
      <div className="ios-card">
        <div className="ios-list-row">
          <span className="label">Email</span>
          <span className="value">{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Lifetime Points</span>
          <span className="value">{user.lifetimePoints.toLocaleString()} points</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Referral Code</span>
          <span className="value">{user.referralCode}</span>
        </div>
      </div>
      
      <button className="ios-button ios-button-primary" onClick={handleShare}>
        Share Referral Code
      </button>
    </div>
  );
};

export default Profile;