import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';

function App() {
  const { user, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');

  const rewards = [
    { id: 1, name: 'Free Coffee', cost: 100, description: '12oz coffee of your choice' },
    { id: 2, name: '10% Discount', cost: 200, description: 'On your next purchase' },
    { id: 3, name: 'Free Pastry', cost: 150, description: 'Any pastry item' },
    { id: 4, name: 'VIP Access', cost: 500, description: 'Skip the line privileges' }
  ];

  const userPoints = user?.points || 0;
  const userTier = userPoints >= 1000 ? 'Gold' : userPoints >= 500 ? 'Silver' : 'Bronze';
  const nextTierPoints = userPoints < 500 ? 500 : userPoints < 1000 ? 1000 : 1000;
  const progress = userPoints < 500 ? (userPoints / 500) * 100 : userPoints < 1000 ? ((userPoints - 500) / 500) * 100 : 100;

  const renderHome = () => (
    <div className="p-4">
      <div className="ios-card mb-4">
        <h3 className="text-lg font-semibold mb-2">Points Balance</h3>
        <div className="text-3xl font-bold text-blue-600">{userPoints}</div>
        <div className="text-sm text-gray-500">Available Points</div>
      </div>
      
      <div className="ios-card mb-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold">Member Status</h3>
          <span className="ios-badge">{userTier}</span>
        </div>
        <div className="mb-2">
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>Progress to {userTier === 'Gold' ? 'Gold' : userTier === 'Silver' ? 'Gold' : 'Silver'}</span>
            <span>{userPoints}/{nextTierPoints}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-blue-600 h-2 rounded-full" style={{width: `${progress}%`}}></div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderRewards = () => (
    <div className="p-4">
      <div className="grid grid-cols-1 gap-4">
        {rewards.map(reward => (
          <div key={reward.id} className="ios-card">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold">{reward.name}</h3>
                <p className="text-sm text-gray-600 mt-1">{reward.description}</p>
                <div className="text-blue-600 font-medium mt-2">{reward.cost} points</div>
              </div>
              <button className="ios-button-primary px-3 py-1 text-sm" disabled={userPoints < reward.cost}>
                {userPoints >= reward.cost ? 'Redeem' : 'Not enough'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCard = () => (
    <div className="p-4">
      <div className="ios-card text-center">
        <h3 className="text-lg font-semibold mb-4">Member Card</h3>
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-lg mb-4">
          <div className="text-sm opacity-90">test13 Member</div>
          <div className="text-xl font-semibold mt-2">{user?.name}</div>
          <div className="text-sm opacity-90 mt-2">ID: {user?.id}</div>
        </div>
        <div className="bg-gray-100 p-4 rounded">
          <div className="text-xs text-gray-500 mb-2">QR Code</div>
          <div className="w-24 h-24 bg-black mx-auto rounded"></div>
        </div>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="p-4">
      <div className="ios-card">
        <div className="ios-list-row">
          <span>Name</span>
          <span className="text-gray-600">{user?.name}</span>
        </div>
        <div className="ios-list-row">
          <span>Email</span>
          <span className="text-gray-600">{user?.email}</span>
        </div>
        <div className="ios-list-row">
          <span>Member Since</span>
          <span className="text-gray-600">2024</span>
        </div>
        <div className="ios-list-row">
          <span>Total Points Earned</span>
          <span className="text-gray-600">{userPoints}</span>
        </div>
        <button className="ios-button w-full mt-4" onClick={logout}>
          Sign Out
        </button>
      </div>
    </div>
  );

  const renderLogin = () => (
    <div className="p-4">
      <div className="ios-card">
        <h2 className="text-xl font-semibold mb-4">Sign In</h2>
        <input type="email" placeholder="Email" className="w-full p-3 border rounded-lg mb-3" />
        <input type="password" placeholder="Password" className="w-full p-3 border rounded-lg mb-4" />
        <button className="ios-button-primary w-full mb-2">Sign In</button>
        <button className="ios-button w-full" onClick={() => setCurrentPage('register')}>
          Create Account
        </button>
      </div>
    </div>
  );

  const renderRegister = () => (
    <div className="p-4">
      <div className="ios-card">
        <h2 className="text-xl font-semibold mb-4">Create Account</h2>
        <input type="text" placeholder="Full Name" className="w-full p-3 border rounded-lg mb-3" />
        <input type="email" placeholder="Email" className="w-full p-3 border rounded-lg mb-3" />
        <input type="password" placeholder="Password" className="w-full p-3 border rounded-lg mb-4" />
        <button className="ios-button-primary w-full mb-2">Create Account</button>
        <button className="ios-button w-full" onClick={() => setCurrentPage('login')}>
          Already have an account?
        </button>
      </div>
    </div>
  );

  const renderContent = () => {
    if (!user && currentPage !== 'register') return renderLogin();
    if (!user && currentPage === 'register') return renderRegister();
    
    switch(currentPage) {
      case 'rewards': return renderRewards();
      case 'card': return renderCard();
      case 'profile': return renderProfile();
      default: return renderHome();
    }
  };

  const getPageTitle = () => {
    if (!user) return currentPage === 'register' ? 'Create Account' : 'Sign In';
    switch(currentPage) {
      case 'rewards': return 'Rewards';
      case 'card': return 'Member Card';
      case 'profile': return 'Profile';
      default: return 'test13';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="ios-nav-bar">
        <h1 className="ios-nav-title-large">{getPageTitle()}</h1>
      </div>
      
      <div className="pb-20">
        {renderContent()}
      </div>

      {user && (
        <div className="ios-tab-bar">
          <button 
            className={`ios-tab-item ${currentPage === 'home' ? 'active' : ''}`}
            onClick={() => setCurrentPage('home')}
          >
            <span className="text-xl">🏠</span>
            <span>Home</span>
          </button>
          <button 
            className={`ios-tab-item ${currentPage === 'rewards' ? 'active' : ''}`}
            onClick={() => setCurrentPage('rewards')}
          >
            <span className="text-xl">🎁</span>
            <span>Rewards</span>
          </button>
          <button 
            className={`ios-tab-item ${currentPage === 'card' ? 'active' : ''}`}
            onClick={() => setCurrentPage('card')}
          >
            <span className="text-xl">💳</span>
            <span>Card</span>
          </button>
          <button 
            className={`ios-tab-item ${currentPage === 'profile' ? 'active' : ''}`}
            onClick={() => setCurrentPage('profile')}
          >
            <span className="text-xl">👤</span>
            <span>Profile</span>
          </button>
        </div>
      )}
    </div>
  );
}

export default App;