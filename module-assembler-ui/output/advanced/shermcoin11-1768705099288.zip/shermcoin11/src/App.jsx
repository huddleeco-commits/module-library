import { useState } from 'react';
import { useAuth } from './context/AuthContext';

function App() {
  const { user, login, register, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({ name: '', email: '', password: '' });

  const handleLogin = async (e) => {
    e.preventDefault();
    await login(loginForm.email, loginForm.password);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    await register(registerForm.name, registerForm.email, registerForm.password);
  };

  const rewards = [
    { id: 1, name: 'Free Coffee', cost: 500, image: '☕' },
    { id: 2, name: '10% Off', cost: 200, image: '🎫' },
    { id: 3, name: 'Free Dessert', cost: 300, image: '🍰' },
    { id: 4, name: 'Free Meal', cost: 1000, image: '🍽️' }
  ];

  const getTier = (points) => {
    if (points >= 1000) return { name: 'Gold', color: 'text-yellow-400', next: null, progress: 100 };
    if (points >= 500) return { name: 'Silver', color: 'text-gray-400', next: 1000, progress: ((points - 500) / 500) * 100 };
    return { name: 'Bronze', color: 'text-amber-600', next: 500, progress: (points / 500) * 100 };
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 w-full max-w-md">
          <h1 className="text-3xl font-bold text-white text-center mb-8">ShermCoin11</h1>
          {currentPage === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <input
                type="email"
                placeholder="Email"
                value={loginForm.email}
                onChange={(e) => setLoginForm({...loginForm, email: e.target.value})}
                className="w-full p-3 rounded-lg bg-white/20 text-white placeholder-white/70 border border-white/30"
              />
              <input
                type="password"
                placeholder="Password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                className="w-full p-3 rounded-lg bg-white/20 text-white placeholder-white/70 border border-white/30"
              />
              <button type="submit" className="w-full bg-white/20 text-white p-3 rounded-lg font-semibold">Login</button>
              <p className="text-center text-white/80">
                Don't have an account?
                <button onClick={() => setCurrentPage('register')} className="ml-1 underline">Sign up</button>
              </p>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <input
                type="text"
                placeholder="Name"
                value={registerForm.name}
                onChange={(e) => setRegisterForm({...registerForm, name: e.target.value})}
                className="w-full p-3 rounded-lg bg-white/20 text-white placeholder-white/70 border border-white/30"
              />
              <input
                type="email"
                placeholder="Email"
                value={registerForm.email}
                onChange={(e) => setRegisterForm({...registerForm, email: e.target.value})}
                className="w-full p-3 rounded-lg bg-white/20 text-white placeholder-white/70 border border-white/30"
              />
              <input
                type="password"
                placeholder="Password"
                value={registerForm.password}
                onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
                className="w-full p-3 rounded-lg bg-white/20 text-white placeholder-white/70 border border-white/30"
              />
              <button type="submit" className="w-full bg-white/20 text-white p-3 rounded-lg font-semibold">Register</button>
              <p className="text-center text-white/80">
                Already have an account?
                <button onClick={() => setCurrentPage('login')} className="ml-1 underline">Login</button>
              </p>
            </form>
          )}
        </div>
      </div>
    );
  }

  const tier = getTier(user.points || 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-600">
      <div className="pb-20">
        {currentPage === 'home' && (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-white mb-6">Welcome, {user.name}</h1>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 mb-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-white mb-2">{user.points || 0}</div>
                <div className="text-white/80">ShermsCoin Balance</div>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
              <div className="flex justify-between items-center mb-3">
                <span className={`font-semibold ${tier.color}`}>{tier.name} Member</span>
                {tier.next && <span className="text-white/80">{tier.next} pts</span>}
              </div>
              <div className="bg-white/20 rounded-full h-2">
                <div className="bg-white rounded-full h-2" style={{width: `${tier.progress}%`}}></div>
              </div>
            </div>
          </div>
        )}

        {currentPage === 'rewards' && (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-white mb-6">Rewards</h1>
            <div className="grid grid-cols-2 gap-4">
              {rewards.map(reward => (
                <div key={reward.id} className="bg-white/10 backdrop-blur-lg rounded-xl p-4">
                  <div className="text-3xl mb-2">{reward.image}</div>
                  <div className="text-white font-semibold mb-1">{reward.name}</div>
                  <div className="text-white/80 text-sm">{reward.cost} coins</div>
                  <button 
                    disabled={(user.points || 0) < reward.cost}
                    className={`w-full mt-3 p-2 rounded-lg text-sm font-semibold ${
                      (user.points || 0) >= reward.cost ? 'bg-white/20 text-white' : 'bg-white/10 text-white/50'
                    }`}
                  >
                    Redeem
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {currentPage === 'card' && (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-white mb-6">Member Card</h1>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
              <div className="text-center">
                <h2 className="text-xl font-bold text-white mb-2">ShermCoin11</h2>
                <div className={`text-lg ${tier.color} mb-4`}>{tier.name} Member</div>
                <div className="bg-white/20 rounded-xl p-8 mb-4">
                  <div className="text-6xl">📱</div>
                </div>
                <div className="text-white font-semibold">{user.name}</div>
                <div className="text-white/80 text-sm">{user.email}</div>
              </div>
            </div>
          </div>
        )}

        {currentPage === 'profile' && (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-white mb-6">Profile</h1>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 mb-6">
              <div className="space-y-4">
                <div>
                  <label className="text-white/80 text-sm">Name</label>
                  <div className="text-white font-semibold">{user.name}</div>
                </div>
                <div>
                  <label className="text-white/80 text-sm">Email</label>
                  <div className="text-white font-semibold">{user.email}</div>
                </div>
                <div>
                  <label className="text-white/80 text-sm">Member Since</label>
                  <div className="text-white font-semibold">Today</div>
                </div>
              </div>
            </div>
            <button
              onClick={logout}
              className="w-full bg-red-500/20 text-red-300 p-3 rounded-lg font-semibold"
            >
              Logout
            </button>
          </div>
        )}
      </div>

      <nav className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-lg border-t border-white/20">
        <div className="flex">
          {[
            { id: 'home', icon: '🏠', label: 'Home' },
            { id: 'rewards', icon: '🎁', label: 'Rewards' },
            { id: 'card', icon: '💳', label: 'Card' },
            { id: 'profile', icon: '👤', label: 'Profile' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setCurrentPage(tab.id)}
              className={`flex-1 p-4 text-center ${
                currentPage === tab.id ? 'text-white' : 'text-white/60'
              }`}
            >
              <div className="text-xl mb-1">{tab.icon}</div>
              <div className="text-xs">{tab.label}</div>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

export default App;