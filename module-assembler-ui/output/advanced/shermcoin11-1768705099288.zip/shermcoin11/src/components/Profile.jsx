import React, { useState, useEffect } from 'react';
import './Profile.css';

const Profile = () => {
  const [user, setUser] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchUserProfile();
  }, []);

  const fetchUserProfile = async () => {
    try {
      const response = await fetch('/api/profile', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await response.json();
      setUser(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  const copyReferralCode = () => {
    navigator.clipboard.writeText(user.referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareReferral = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join with my referral code',
        text: `Use my referral code: ${user.referralCode}`,
        url: `${window.location.origin}/signup?ref=${user.referralCode}`
      });
    }
  };

  const getTierBadge = (tier) => {
    const tiers = {
      bronze: { name: 'Bronze', color: '#CD7F32' },
      silver: { name: 'Silver', color: '#C0C0C0' },
      gold: { name: 'Gold', color: '#FFD700' },
      platinum: { name: 'Platinum', color: '#E5E4E2' }
    };
    return tiers[tier] || tiers.bronze;
  };

  if (!user) return <div className="profile-loading">Loading...</div>;

  const tierInfo = getTierBadge(user.tier);

  return (
    <div className="profile-container">
      <div className="profile-header">
        <div className="profile-avatar">
          {user.name?.charAt(0).toUpperCase()}
        </div>
        <h1 className="profile-name">{user.name}</h1>
        <p className="profile-email">{user.email}</p>
      </div>

      <div className="tier-section">
        <div 
          className="tier-badge" 
          style={{ backgroundColor: tierInfo.color }}
        >
          {tierInfo.name} Member
        </div>
      </div>

      <div className="coins-section">
        <h2>Lifetime ShermsCoin</h2>
        <div className="coins-amount">
          {user.lifetimeCoins?.toLocaleString() || 0}
        </div>
      </div>

      <div className="referral-section">
        <h2>Referral Code</h2>
        <div className="referral-code-container">
          <div className="referral-code">{user.referralCode}</div>
          <div className="referral-actions">
            <button 
              onClick={copyReferralCode}
              className={`copy-btn ${copied ? 'copied' : ''}`}
            >
              {copied ? 'Copied!' : 'Copy'}
            </button>
            <button onClick={shareReferral} className="share-btn">
              Share
            </button>
          </div>
        </div>
      </div>

      <div className="stats-section">
        <div className="stat-item">
          <span className="stat-label">Referrals</span>
          <span className="stat-value">{user.referralCount || 0}</span>
        </div>
        <div className="stat-item">
          <span className="stat-label">Current Balance</span>
          <span className="stat-value">{user.currentBalance?.toLocaleString() || 0}</span>
        </div>
      </div>
    </div>
  );
};

export default Profile;