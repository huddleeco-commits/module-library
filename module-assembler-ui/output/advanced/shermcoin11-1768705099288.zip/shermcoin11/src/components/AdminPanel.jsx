import React, { useState, useEffect } from 'react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [coinAmount, setCoinAmount] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [stats, setStats] = useState({ totalCustomers: 0, totalCoins: 0, totalTransactions: 0 });

  useEffect(() => {
    fetchCustomers();
    fetchStats();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch('/api/customers');
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const addCoins = async (e) => {
    e.preventDefault();
    try {
      await fetch('/api/add-coins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId: selectedCustomer, amount: parseInt(coinAmount) })
      });
      setCoinAmount('');
      setSelectedCustomer('');
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error adding coins:', error);
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="admin-panel">
      <h1>Admin Panel - ShermsCoin Loyalty</h1>
      
      <div className="tab-navigation">
        <button 
          className={activeTab === 'customers' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('customers')}
        >
          Customers
        </button>
        <button 
          className={activeTab === 'add-coins' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('add-coins')}
        >
          Add ShermsCoin
        </button>
        <button 
          className={activeTab === 'stats' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('stats')}
        >
          Statistics
        </button>
      </div>

      <div className="tab-content">
        {activeTab === 'customers' && (
          <div className="customers-tab">
            <h2>Customer Management</h2>
            <input
              type="text"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
            <table className="customers-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>ShermsCoin Balance</th>
                  <th>Join Date</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map(customer => (
                  <tr key={customer.id}>
                    <td>{customer.name}</td>
                    <td>{customer.email}</td>
                    <td>{customer.balance || 0}</td>
                    <td>{new Date(customer.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'add-coins' && (
          <div className="add-coins-tab">
            <h2>Add ShermsCoin to Customer</h2>
            <form onSubmit={addCoins} className="add-coins-form">
              <div className="form-group">
                <label>Select Customer:</label>
                <select 
                  value={selectedCustomer} 
                  onChange={(e) => setSelectedCustomer(e.target.value)}
                  required
                >
                  <option value="">Choose customer...</option>
                  {customers.map(customer => (
                    <option key={customer.id} value={customer.id}>
                      {customer.name} - {customer.email}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>ShermsCoin Amount:</label>
                <input
                  type="number"
                  value={coinAmount}
                  onChange={(e) => setCoinAmount(e.target.value)}
                  min="1"
                  required
                />
              </div>
              <button type="submit" className="add-btn">Add ShermsCoin</button>
            </form>
          </div>
        )}

        {activeTab === 'stats' && (
          <div className="stats-tab">
            <h2>Platform Statistics</h2>
            <div className="stats-grid">
              <div className="stat-card">
                <h3>Total Customers</h3>
                <div className="stat-value">{stats.totalCustomers}</div>
              </div>
              <div className="stat-card">
                <h3>Total ShermsCoin Issued</h3>
                <div className="stat-value">{stats.totalCoins}</div>
              </div>
              <div className="stat-card">
                <h3>Total Transactions</h3>
                <div className="stat-value">{stats.totalTransactions}</div>
              </div>
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        .admin-panel {
          max-width: 1200px;
          margin: 0 auto;
          padding: 20px;
          font-family: Arial, sans-serif;
        }
        
        h1 {
          color: #333;
          margin-bottom: 30px;
        }
        
        .tab-navigation {
          display: flex;
          border-bottom: 2px solid #ddd;
          margin-bottom: 30px;
        }
        
        .tab {
          padding: 12px 24px;
          background: none;
          border: none;
          cursor: pointer;
          font-size: 16px;
          border-bottom: 3px solid transparent;
          transition: all 0.3s;
        }
        
        .tab.active {
          color: #007bff;
          border-bottom-color: #007bff;
        }
        
        .search-input {
          width: 300px;
          padding: 10px;
          margin-bottom: 20px;
          border: 1px solid #ddd;
          border-radius: 4px;
          font-size: 16px;
        }
        
        .customers-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        
        .customers-table th,
        .customers-table td {
          padding: 12px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        
        .customers-table th {
          background-color: #f8f9fa;
          font-weight: bold;
        }
        
        .add-coins-form {
          max-width: 400px;
        }
        
        .form-group {
          margin-bottom: 20px;
        }
        
        .form-group label {
          display: block;
          margin-bottom: 5px;
          font-weight: bold;
        }
        
        .form-group input,
        .form-group select {
          width: 100%;
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 4px;
          font-size: 16px;
        }
        
        .add-btn {
          background-color: #28a745;
          color: white;
          padding: 12px 24px;
          border: none;
          border-radius: 4px;
          font-size: 16px;
          cursor: pointer;
          transition: background-color 0.3s;
        }
        
        .add-btn:hover {
          background-color: #218838;
        }
        
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 20px;
          margin-top: 20px;
        }
        
        .stat-card {
          background: #f8f9fa;
          padding: 30px;
          border-radius: 8px;
          text-align: center;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .stat-card h3 {
          margin: 0 0 15px 0;
          color: #666;
          font-size: 16px;
        }
        
        .stat-value {
          font-size: 36px;
          font-weight: bold;
          color: #007bff;
        }
      `}</style>
    </div>
  );
};

export default AdminPanel;