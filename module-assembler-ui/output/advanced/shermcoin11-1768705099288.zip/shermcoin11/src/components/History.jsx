import React, { useState } from 'react';

const History = () => {
  const [activeTab, setActiveTab] = useState('all');

  const transactions = [
    { id: 1, type: 'earned', amount: 50, description: 'Purchase at Store #1', date: '2024-01-15' },
    { id: 2, type: 'spent', amount: -100, description: 'Redeemed Free Coffee', date: '2024-01-14' },
    { id: 3, type: 'earned', amount: 25, description: 'Daily Check-in', date: '2024-01-13' },
    { id: 4, type: 'earned', amount: 75, description: 'Purchase at Store #2', date: '2024-01-12' },
    { id: 5, type: 'spent', amount: -150, description: 'Redeemed Free Pastry', date: '2024-01-11' }
  ];

  const filteredTransactions = transactions.filter(transaction => {
    if (activeTab === 'all') return true;
    return transaction.type === activeTab;
  });

  return (
    <div className="history">
      <h2>Transaction History</h2>
      
      <div className="history-tabs">
        <button 
          className={activeTab === 'all' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('all')}
        >
          All
        </button>
        <button 
          className={activeTab === 'earned' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('earned')}
        >
          Earned
        </button>
        <button 
          className={activeTab === 'spent' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('spent')}
        >
          Spent
        </button>
      </div>

      <div className="transaction-list">
        {filteredTransactions.map(transaction => (
          <div key={transaction.id} className="transaction-item">
            <div className="transaction-info">
              <div className="transaction-description">{transaction.description}</div>
              <div className="transaction-date">{transaction.date}</div>
            </div>
            <div className={`transaction-amount ${transaction.type}`}>
              {transaction.amount > 0 ? '+' : ''}{transaction.amount} ShermsCoin
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default History;