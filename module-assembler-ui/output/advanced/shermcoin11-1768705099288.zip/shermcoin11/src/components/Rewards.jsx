import React, { useState } from 'react';

const Rewards = () => {
  const [showModal, setShowModal] = useState(false);
  const [selectedReward, setSelectedReward] = useState(null);

  const rewards = [
    { id: 1, title: "Free Coffee", cost: 100, description: "One free coffee of your choice" },
    { id: 2, title: "10% Discount", cost: 250, description: "10% off your next purchase" },
    { id: 3, title: "Free Pastry", cost: 150, description: "One free pastry item" },
    { id: 4, title: "Free Lunch", cost: 500, description: "Free lunch meal up to $15" }
  ];

  const handleRedeem = (reward) => {
    setSelectedReward(reward);
    setShowModal(true);
  };

  const confirmRedeem = () => {
    setShowModal(false);
    setSelectedReward(null);
  };

  return (
    <div className="rewards">
      <h2>Available Rewards</h2>
      <div className="rewards-grid">
        {rewards.map(reward => (
          <div key={reward.id} className="reward-card">
            <h3>{reward.title}</h3>
            <p>{reward.description}</p>
            <div className="reward-cost">{reward.cost} ShermsCoin</div>
            <button onClick={() => handleRedeem(reward)} className="redeem-btn">
              Redeem
            </button>
          </div>
        ))}
      </div>
      
      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Confirm Redemption</h3>
            <p>Redeem {selectedReward?.title} for {selectedReward?.cost} ShermsCoin?</p>
            <div className="modal-buttons">
              <button onClick={() => setShowModal(false)} className="cancel-btn">Cancel</button>
              <button onClick={confirmRedeem} className="confirm-btn">Confirm</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rewards;