import React from 'react';
import './MemberCard.css';

const MemberCard = ({ user }) => {
  const tierColors = {
    Bronze: '#CD7F32',
    Silver: '#C0C0C0',
    Gold: '#FFD700',
    Platinum: '#E5E4E2'
  };

  return (
    <div className="member-card-container">
      <div 
        className="member-card"
        style={{ 
          background: `linear-gradient(135deg, ${tierColors[user.tier]}20, ${tierColors[user.tier]}10)`,
          borderColor: tierColors[user.tier]
        }}
      >
        <div className="card-header">
          <h2>ShermsCoin Member</h2>
          <div 
            className="tier-badge"
            style={{ backgroundColor: tierColors[user.tier] }}
          >
            {user.tier}
          </div>
        </div>
        
        <div className="card-body">
          <div className="member-info">
            <h3>{user.name}</h3>
            <p>Member ID: {user.id}</p>
            <p>Points: {user.points.toLocaleString()} SC</p>
          </div>
          
          <div className="qr-section">
            <div className="qr-placeholder">
              <div className="qr-code">
                <div className="qr-grid">
                  {Array.from({ length: 64 }, (_, i) => (
                    <div key={i} className={`qr-pixel ${Math.random() > 0.5 ? 'filled' : ''}`}></div>
                  ))}
                </div>
              </div>
              <p>Scan to earn points</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MemberCard;