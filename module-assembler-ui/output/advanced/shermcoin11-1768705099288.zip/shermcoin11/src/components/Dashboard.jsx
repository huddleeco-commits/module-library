import React from 'react';
import './Dashboard.css';

const Dashboard = ({ user }) => {
  const tierColors = {
    Bronze: '#CD7F32',
    Silver: '#C0C0C0',
    Gold: '#FFD700',
    Platinum: '#E5E4E2'
  };

  const tierThresholds = {
    Bronze: 0,
    Silver: 1000,
    Gold: 5000,
    Platinum: 10000
  };

  const getNextTier = (currentTier) => {
    const tiers = ['Bronze', 'Silver', 'Gold', 'Platinum'];
    const currentIndex = tiers.indexOf(currentTier);
    return currentIndex < tiers.length - 1 ? tiers[currentIndex + 1] : null;
  };

  const getProgress = () => {
    const nextTier = getNextTier(user.tier);
    if (!nextTier) return 100;
    const currentThreshold = tierThresholds[user.tier];
    const nextThreshold = tierThresholds[nextTier];
    const progress = ((user.points - currentThreshold) / (nextThreshold - currentThreshold)) * 100;
    return Math.max(0, Math.min(100, progress));
  };

  const nextTier = getNextTier(user.tier);
  const progress = getProgress();

  return (
    <div className="dashboard">
      <div className="welcome-card">
        <h1>Welcome, {user.name}!</h1>
        <div className="points-balance">
          <span className="points-amount">{user.points.toLocaleString()}</span>
          <span className="currency">ShermsCoin</span>
        </div>
      </div>
      
      <div className="tier-card">
        <div className="tier-badge" style={{ backgroundColor: tierColors[user.tier] }}>
          <span className="tier-name">{user.tier}</span>
        </div>
        
        {nextTier && (
          <div className="progress-section">
            <div className="progress-info">
              <span>Progress to {nextTier}</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ 
                  width: `${progress}%`,
                  backgroundColor: tierColors[nextTier]
                }}
              ></div>
            </div>
            <p>{tierThresholds[nextTier] - user.points} ShermsCoin until {nextTier}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;