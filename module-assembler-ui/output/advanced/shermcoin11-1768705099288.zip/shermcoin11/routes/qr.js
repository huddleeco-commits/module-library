const express = require('express');
const QRCode = require('qrcode');
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

router.get('/member/:id', async (req, res) => {
  try {
    const userId = req.params.id;
    
    const userResult = await pool.query(
      'SELECT id, name, tier FROM users WHERE id = $1',
      [userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(404).json({error: 'Member not found'});
    }
    
    const memberData = {
      id: userId,
      name: userResult.rows[0].name,
      tier: userResult.rows[0].tier,
      timestamp: Date.now()
    };
    
    const qrString = JSON.stringify(memberData);
    const qrImage = await QRCode.toDataURL(qrString);
    
    res.setHeader('Content-Type', 'text/html');
    res.send(`
      <html>
        <body style="text-align: center; font-family: Arial;">
          <h2>ShermCoin11 Member QR</h2>
          <p><strong>${userResult.rows[0].name}</strong></p>
          <p>Tier: ${userResult.rows[0].tier}</p>
          <img src="${qrImage}" alt="Member QR Code" style="max-width: 300px;" />
          <p><small>ID: ${userId}</small></p>
        </body>
      </html>
    `);
  } catch (error) {
    res.status(500).json({error: 'Failed to generate QR code'});
  }
});

router.post('/scan', verifyToken, async (req, res) => {
  try {
    const { qrData } = req.body;
    
    if (!qrData) {
      return res.status(400).json({error: 'QR data required'});
    }
    
    let memberData;
    try {
      memberData = JSON.parse(qrData);
    } catch (e) {
      return res.status(400).json({error: 'Invalid QR code format'});
    }
    
    if (!memberData.id) {
      return res.status(400).json({error: 'Invalid member QR code'});
    }
    
    const userResult = await pool.query(
      'SELECT id, name, email, points_balance, tier FROM users WHERE id = $1',
      [memberData.id]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(404).json({error: 'Member not found'});
    }
    
    const user = userResult.rows[0];
    
    res.json({
      valid: true,
      member: {
        id: user.id,
        name: user.name,
        email: user.email,
        points_balance: user.points_balance,
        tier: user.tier
      }
    });
  } catch (error) {
    res.status(500).json({error: 'Failed to verify QR code'});
  }
});

module.exports = router;