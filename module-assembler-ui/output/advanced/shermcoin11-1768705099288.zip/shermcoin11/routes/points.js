const express = require('express');
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const tiers = {
  'Bronze': { min: 0, multiplier: 1 },
  'Silver': { min: 500, multiplier: 1.25 },
  'Gold': { min: 2000, multiplier: 1.5 },
  'Platinum': { min: 5000, multiplier: 2 }
};

const updateTier = async (userId, points) => {
  let newTier = 'Bronze';
  if (points >= 5000) newTier = 'Platinum';
  else if (points >= 2000) newTier = 'Gold';
  else if (points >= 500) newTier = 'Silver';
  
  await pool.query('UPDATE users SET tier = $1 WHERE id = $2', [newTier, userId]);
  return newTier;
};

router.get('/balance', verifyToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT points_balance, tier FROM users WHERE id = $1',
      [req.user.id]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({error: 'Failed to fetch balance'});
  }
});

router.get('/history', verifyToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM point_transactions WHERE user_id = $1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({error: 'Failed to fetch history'});
  }
});

router.post('/earn', verifyToken, async (req, res) => {
  try {
    const { points, description = 'Points earned' } = req.body;
    
    if (!points || points <= 0) {
      return res.status(400).json({error: 'Invalid points amount'});
    }
    
    const userResult = await pool.query('SELECT points_balance, tier FROM users WHERE id = $1', [req.user.id]);
    const currentUser = userResult.rows[0];
    const multiplier = tiers[currentUser.tier].multiplier;
    const earnedPoints = Math.floor(points * multiplier);
    const newBalance = currentUser.points_balance + earnedPoints;
    
    await pool.query('BEGIN');
    
    await pool.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, req.user.id]
    );
    
    await pool.query(
      'INSERT INTO point_transactions (user_id, points, type, description) VALUES ($1, $2, $3, $4)',
      [req.user.id, earnedPoints, 'earn', description]
    );
    
    const newTier = await updateTier(req.user.id, newBalance);
    
    await pool.query('COMMIT');
    
    res.json({ points: earnedPoints, balance: newBalance, tier: newTier });
  } catch (error) {
    await pool.query('ROLLBACK');
    res.status(500).json({error: 'Failed to earn points'});
  }
});

router.post('/spend', verifyToken, async (req, res) => {
  try {
    const { points, description = 'Points spent' } = req.body;
    
    if (!points || points <= 0) {
      return res.status(400).json({error: 'Invalid points amount'});
    }
    
    const userResult = await pool.query('SELECT points_balance FROM users WHERE id = $1', [req.user.id]);
    const currentBalance = userResult.rows[0].points_balance;
    
    if (currentBalance < points) {
      return res.status(400).json({error: 'Insufficient points'});
    }
    
    const newBalance = currentBalance - points;
    
    await pool.query('BEGIN');
    
    await pool.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, req.user.id]
    );
    
    await pool.query(
      'INSERT INTO point_transactions (user_id, points, type, description) VALUES ($1, $2, $3, $4)',
      [req.user.id, -points, 'spend', description]
    );
    
    const newTier = await updateTier(req.user.id, newBalance);
    
    await pool.query('COMMIT');
    
    res.json({ points: -points, balance: newBalance, tier: newTier });
  } catch (error) {
    await pool.query('ROLLBACK');
    res.status(500).json({error: 'Failed to spend points'});
  }
});

module.exports = router;