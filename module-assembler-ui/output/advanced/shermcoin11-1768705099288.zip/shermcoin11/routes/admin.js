const express = require('express');
const { Pool } = require('pg');
const { verifyToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

router.get('/customers', verifyToken, requireAdmin, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, email, points_balance, tier, created_at FROM users WHERE is_admin = false ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({error: 'Failed to fetch customers'});
  }
});

router.get('/stats', verifyToken, requireAdmin, async (req, res) => {
  try {
    const customerCount = await pool.query('SELECT COUNT(*) FROM users WHERE is_admin = false');
    const totalPoints = await pool.query('SELECT SUM(points_balance) FROM users WHERE is_admin = false');
    const tierStats = await pool.query(
      'SELECT tier, COUNT(*) as count FROM users WHERE is_admin = false GROUP BY tier'
    );
    const recentTransactions = await pool.query(
      'SELECT COUNT(*) FROM point_transactions WHERE created_at > NOW() - INTERVAL \'7 days\''
    );
    
    res.json({
      totalCustomers: parseInt(customerCount.rows[0].count),
      totalPointsIssued: parseInt(totalPoints.rows[0].sum) || 0,
      tierDistribution: tierStats.rows,
      weeklyTransactions: parseInt(recentTransactions.rows[0].count)
    });
  } catch (error) {
    res.status(500).json({error: 'Failed to fetch stats'});
  }
});

router.post('/:id/points', verifyToken, requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const { points, description = 'Admin adjustment' } = req.body;
    
    if (!points) {
      return res.status(400).json({error: 'Points amount required'});
    }
    
    const userResult = await pool.query('SELECT points_balance FROM users WHERE id = $1', [userId]);
    
    if (userResult.rows.length === 0) {
      return res.status(404).json({error: 'User not found'});
    }
    
    const currentBalance = userResult.rows[0].points_balance;
    const newBalance = Math.max(0, currentBalance + points);
    
    await pool.query('BEGIN');
    
    await pool.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, userId]
    );
    
    await pool.query(
      'INSERT INTO point_transactions (user_id, points, type, description) VALUES ($1, $2, $3, $4)',
      [userId, points, points > 0 ? 'admin_add' : 'admin_remove', description]
    );
    
    let newTier = 'Bronze';
    if (newBalance >= 5000) newTier = 'Platinum';
    else if (newBalance >= 2000) newTier = 'Gold';
    else if (newBalance >= 500) newTier = 'Silver';
    
    await pool.query('UPDATE users SET tier = $1 WHERE id = $2', [newTier, userId]);
    
    await pool.query('COMMIT');
    
    res.json({ 
      message: 'Points updated successfully', 
      newBalance, 
      tier: newTier 
    });
  } catch (error) {
    await pool.query('ROLLBACK');
    res.status(500).json({error: 'Failed to update points'});
  }
});

module.exports = router;