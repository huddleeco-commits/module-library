const express = require('express');
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

router.get('/list', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, description, points_cost, category, available FROM rewards WHERE available = true ORDER BY points_cost'
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({error: 'Failed to fetch rewards'});
  }
});

router.post('/redeem/:id', verifyToken, async (req, res) => {
  try {
    const rewardId = req.params.id;
    
    const rewardResult = await pool.query(
      'SELECT * FROM rewards WHERE id = $1 AND available = true',
      [rewardId]
    );
    
    if (rewardResult.rows.length === 0) {
      return res.status(404).json({error: 'Reward not found or unavailable'});
    }
    
    const reward = rewardResult.rows[0];
    
    const userResult = await pool.query(
      'SELECT points_balance FROM users WHERE id = $1',
      [req.user.id]
    );
    
    const userBalance = userResult.rows[0].points_balance;
    
    if (userBalance < reward.points_cost) {
      return res.status(400).json({error: 'Insufficient ShermsCoin balance'});
    }
    
    const newBalance = userBalance - reward.points_cost;
    
    await pool.query('BEGIN');
    
    await pool.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, req.user.id]
    );
    
    await pool.query(
      'INSERT INTO point_transactions (user_id, points, type, description) VALUES ($1, $2, $3, $4)',
      [req.user.id, -reward.points_cost, 'redeem', `Redeemed: ${reward.name}`]
    );
    
    await pool.query(
      'INSERT INTO redemptions (user_id, reward_id, points_spent, status) VALUES ($1, $2, $3, $4)',
      [req.user.id, rewardId, reward.points_cost, 'pending']
    );
    
    await pool.query('COMMIT');
    
    res.json({ 
      message: 'Reward redeemed successfully', 
      reward: reward.name, 
      pointsSpent: reward.points_cost, 
      newBalance 
    });
  } catch (error) {
    await pool.query('ROLLBACK');
    res.status(500).json({error: 'Failed to redeem reward'});
  }
});

module.exports = router;