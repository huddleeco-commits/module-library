# ShermCoin11 Rewards

Premium loyalty program with ShermsCoin rewards system.

## Quick Start

```bash
npm install
cp .env.example .env
npm run dev
```

Open http://localhost:5173

## Features
- 🎯 ShermsCoin earning & redemption
- 🏆 Tier system: Bronze → Silver → Gold → Platinum
- 🎁 Rewards catalog with 4 rewards
- 📱 Mobile-first PWA design
- 🔐 Secure authentication
- 👑 Admin dashboard
- 📊 Analytics & reporting

## Tier Benefits
- **Bronze**: 1x ShermsCoin multiplier (0+ ShermsCoin)\n- **Silver**: 1.25x ShermsCoin multiplier (500+ ShermsCoin)\n- **Gold**: 1.5x ShermsCoin multiplier (2000+ ShermsCoin)\n- **Platinum**: 2x ShermsCoin multiplier (5000+ ShermsCoin)