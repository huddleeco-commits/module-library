const express = require('express');
const db = require('../database/db');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

const TIER_THRESHOLDS = {
  Bronze: { min: 0, multiplier: 1 },
  Silver: { min: 500, multiplier: 1.25 },
  Gold: { min: 2000, multiplier: 1.5 },
  Platinum: { min: 5000, multiplier: 2 }
};

const calculateTier = (points) => {
  if (points >= 5000) return 'Platinum';
  if (points >= 2000) return 'Gold';
  if (points >= 500) return 'Silver';
  return 'Bronze';
};

router.get('/balance', verifyToken, async (req, res) => {
  try {
    const result = await db.query('SELECT points_balance, tier FROM users WHERE id = $1', [req.userId]);
    
    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Failed to get balance' });
  }
});

router.get('/history', verifyToken, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM point_transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
      [req.userId]
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Failed to get history' });
  }
});

router.post('/earn', verifyToken, async (req, res) => {
  try {
    const { amount, description } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }
    
    const userResult = await db.query('SELECT points_balance, tier FROM users WHERE id = $1', [req.userId]);
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    const multiplier = TIER_THRESHOLDS[user.tier].multiplier;
    const earnedPoints = Math.floor(amount * multiplier);
    const newBalance = user.points_balance + earnedPoints;
    const newTier = calculateTier(newBalance);
    
    await db.query('BEGIN');
    
    await db.query(
      'UPDATE users SET points_balance = $1, tier = $2 WHERE id = $3',
      [newBalance, newTier, req.userId]
    );
    
    await db.query(
      'INSERT INTO point_transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [req.userId, 'earned', earnedPoints, description || 'Points earned', newBalance]
    );
    
    await db.query('COMMIT');
    
    res.json({ points_earned: earnedPoints, new_balance: newBalance, new_tier: newTier });
  } catch (error) {
    await db.query('ROLLBACK');
    console.error(error);
    res.status(400).json({ error: 'Failed to earn points' });
  }
});

router.post('/spend', verifyToken, async (req, res) => {
  try {
    const { amount, description } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }
    
    const userResult = await db.query('SELECT points_balance, tier FROM users WHERE id = $1', [req.userId]);
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    
    if (user.points_balance < amount) {
      return res.status(400).json({ error: 'Insufficient points' });
    }
    
    const newBalance = user.points_balance - amount;
    const newTier = calculateTier(newBalance);
    
    await db.query('BEGIN');
    
    await db.query(
      'UPDATE users SET points_balance = $1, tier = $2 WHERE id = $3',
      [newBalance, newTier, req.userId]
    );
    
    await db.query(
      'INSERT INTO point_transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [req.userId, 'spent', -amount, description || 'Points spent', newBalance]
    );
    
    await db.query('COMMIT');
    
    res.json({ points_spent: amount, new_balance: newBalance, new_tier: newTier });
  } catch (error) {
    await db.query('ROLLBACK');
    console.error(error);
    res.status(400).json({ error: 'Failed to spend points' });
  }
});

module.exports = router;