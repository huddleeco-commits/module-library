const express = require('express');
const QRCode = require('qrcode');
const db = require('../database/db');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

router.get('/member/:id', async (req, res) => {
  try {
    const userId = req.params.id;
    
    const userResult = await db.query('SELECT id, name, tier FROM users WHERE id = $1', [userId]);
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const qrData = {
      userId: userId,
      business: 'test12',
      timestamp: Date.now()
    };
    
    const qrCodeImage = await QRCode.toDataURL(JSON.stringify(qrData));
    
    res.json({ qr_code: qrCodeImage, user: userResult.rows[0] });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Failed to generate QR code' });
  }
});

router.post('/scan', verifyToken, async (req, res) => {
  try {
    const { qr_data } = req.body;
    
    if (!qr_data) {
      return res.status(400).json({ error: 'QR data required' });
    }
    
    let parsedData;
    try {
      parsedData = JSON.parse(qr_data);
    } catch {
      return res.status(400).json({ error: 'Invalid QR code format' });
    }
    
    if (!parsedData.userId || parsedData.business !== 'test12') {
      return res.status(400).json({ error: 'Invalid QR code' });
    }
    
    const userResult = await db.query(
      'SELECT id, name, email, points_balance, tier FROM users WHERE id = $1',
      [parsedData.userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'Member not found' });
    }
    
    res.json({ member: userResult.rows[0], valid: true });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Failed to verify QR code' });
  }
});

module.exports = router;