const express = require('express');
const db = require('../database/db');
const { verifyToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.get('/customers', verifyToken, requireAdmin, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT id, email, name, points_balance, tier, created_at FROM users WHERE is_admin = false ORDER BY created_at DESC'
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Failed to get customers' });
  }
});

router.get('/stats', verifyToken, requireAdmin, async (req, res) => {
  try {
    const totalCustomersResult = await db.query('SELECT COUNT(*) as count FROM users WHERE is_admin = false');
    const totalPointsResult = await db.query('SELECT SUM(points_balance) as total FROM users WHERE is_admin = false');
    const totalRedemptionsResult = await db.query('SELECT COUNT(*) as count FROM redemptions');
    const tierStatsResult = await db.query(
      'SELECT tier, COUNT(*) as count FROM users WHERE is_admin = false GROUP BY tier'
    );
    
    const recentTransactionsResult = await db.query(
      'SELECT pt.*, u.name as user_name FROM point_transactions pt JOIN users u ON pt.user_id = u.id ORDER BY pt.created_at DESC LIMIT 20'
    );
    
    res.json({
      total_customers: parseInt(totalCustomersResult.rows[0].count),
      total_points_in_circulation: parseInt(totalPointsResult.rows[0].total) || 0,
      total_redemptions: parseInt(totalRedemptionsResult.rows[0].count),
      tier_distribution: tierStatsResult.rows,
      recent_transactions: recentTransactionsResult.rows
    });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Failed to get stats' });
  }
});

router.post('/:id/points', verifyToken, requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const { amount, description, type } = req.body;
    
    if (!amount || (type !== 'add' && type !== 'subtract')) {
      return res.status(400).json({ error: 'Invalid amount or type' });
    }
    
    const userResult = await db.query('SELECT points_balance FROM users WHERE id = $1', [userId]);
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    const pointChange = type === 'add' ? amount : -amount;
    const newBalance = Math.max(0, user.points_balance + pointChange);
    
    const calculateTier = (points) => {
      if (points >= 5000) return 'Platinum';
      if (points >= 2000) return 'Gold';
      if (points >= 500) return 'Silver';
      return 'Bronze';
    };
    
    const newTier = calculateTier(newBalance);
    
    await db.query('BEGIN');
    
    await db.query(
      'UPDATE users SET points_balance = $1, tier = $2 WHERE id = $3',
      [newBalance, newTier, userId]
    );
    
    await db.query(
      'INSERT INTO point_transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [userId, type === 'add' ? 'admin_added' : 'admin_removed', pointChange, description || 'Admin adjustment', newBalance]
    );
    
    await db.query('COMMIT');
    
    res.json({ new_balance: newBalance, new_tier: newTier });
  } catch (error) {
    await db.query('ROLLBACK');
    console.error(error);
    res.status(400).json({ error: 'Failed to adjust points' });
  }
});

module.exports = router;