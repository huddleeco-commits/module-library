const express = require('express');
const db = require('../database/db');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

router.get('/list', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM rewards WHERE is_active = true ORDER BY points_cost');
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Failed to get rewards' });
  }
});

router.post('/redeem/:id', verifyToken, async (req, res) => {
  try {
    const rewardId = req.params.id;
    
    const rewardResult = await db.query('SELECT * FROM rewards WHERE id = $1 AND is_active = true', [rewardId]);
    if (rewardResult.rows.length === 0) {
      return res.status(400).json({ error: 'Reward not found or inactive' });
    }
    
    const reward = rewardResult.rows[0];
    
    const userResult = await db.query('SELECT points_balance FROM users WHERE id = $1', [req.userId]);
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    
    if (user.points_balance < reward.points_cost) {
      return res.status(400).json({ error: 'Insufficient points' });
    }
    
    const newBalance = user.points_balance - reward.points_cost;
    
    await db.query('BEGIN');
    
    await db.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, req.userId]
    );
    
    await db.query(
      'INSERT INTO point_transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [req.userId, 'spent', -reward.points_cost, `Redeemed: ${reward.name}`, newBalance]
    );
    
    const redemptionResult = await db.query(
      'INSERT INTO redemptions (user_id, reward_id, points_cost, status) VALUES ($1, $2, $3, $4) RETURNING *',
      [req.userId, rewardId, reward.points_cost, 'pending']
    );
    
    await db.query('COMMIT');
    
    res.json({
      message: 'Reward redeemed successfully',
      redemption: redemptionResult.rows[0],
      new_balance: newBalance
    });
  } catch (error) {
    await db.query('ROLLBACK');
    console.error(error);
    res.status(400).json({ error: 'Failed to redeem reward' });
  }
});

module.exports = router;