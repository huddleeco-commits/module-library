import React, { useState } from 'react';

const Profile = () => {
  const [user] = useState({
    name: 'John Doe',
    email: 'john.doe@email.com',
    tier: 'Gold',
    lifetimePoints: 2450,
    referralCode: 'JOHN2024'
  });

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join me on this loyalty app!',
        text: `Use my referral code: ${user.referralCode}`,
        url: window.location.origin
      });
    } else {
      navigator.clipboard.writeText(user.referralCode);
      alert('Referral code copied to clipboard!');
    }
  };

  return (
    <div className="profile-container">
      <div className="ios-card">
        <div className="profile-header">
          <div className="avatar">
            <img src="https://via.placeholder.com/80x80/007AFF/FFFFFF?text=JD" alt="Profile" />
          </div>
          <div className="profile-info">
            <h2>{user.name}</h2>
            <span className="ios-badge ios-badge-gold">{user.tier}</span>
          </div>
        </div>
      </div>

      <div className="ios-card">
        <div className="ios-list-row">
          <span className="label">Email</span>
          <span className="value">{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Lifetime Points</span>
          <span className="value">{user.lifetimePoints.toLocaleString()} points</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Referral Code</span>
          <span className="value referral-code">{user.referralCode}</span>
        </div>
      </div>

      <button className="ios-button ios-button-primary" onClick={handleShare}>
        Share Referral Code
      </button>
    </div>
  );
};

export default Profile;