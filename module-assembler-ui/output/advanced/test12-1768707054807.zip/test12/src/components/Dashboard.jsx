import React from 'react';

function Dashboard({ user }) {
  const getTierColor = (tier) => {
    switch (tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const getNextTierProgress = (points) => {
    if (points < 1000) return { next: 'Silver', progress: points / 1000 * 100, needed: 1000 - points };
    if (points < 5000) return { next: 'Gold', progress: (points - 1000) / 4000 * 100, needed: 5000 - points };
    if (points < 10000) return { next: 'Platinum', progress: (points - 5000) / 5000 * 100, needed: 10000 - points };
    return { next: 'Max', progress: 100, needed: 0 };
  };

  const tierProgress = getNextTierProgress(user?.points || 0);

  return (
    <div className="ios-card">
      <div className="points-display">
        <h1>{user?.points || 0}</h1>
        <p>points</p>
      </div>
      
      <div className="tier-section">
        <span 
          className="ios-badge tier-badge"
          style={{ backgroundColor: getTierColor(user?.tier || 'Bronze') }}
        >
          {user?.tier || 'Bronze'}
        </span>
      </div>

      {tierProgress.next !== 'Max' && (
        <div className="progress-section">
          <p>Next tier: {tierProgress.next}</p>
          <div className="progress-bar">
            <div 
              className="progress-fill"
              style={{ width: `${tierProgress.progress}%` }}
            ></div>
          </div>
          <p>{tierProgress.needed} points to go</p>
        </div>
      )}
    </div>
  );
}

export default Dashboard;