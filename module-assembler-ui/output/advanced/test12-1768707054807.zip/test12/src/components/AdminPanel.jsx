import React, { useState, useEffect } from 'react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [pointsAmount, setPointsAmount] = useState('');
  const [stats, setStats] = useState({ totalCustomers: 0, totalPoints: 0, avgPoints: 0 });

  useEffect(() => {
    fetchCustomers();
    fetchStats();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch('/api/customers');
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const addPoints = async () => {
    if (!selectedCustomer || !pointsAmount) return;
    try {
      await fetch('/api/add-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId: selectedCustomer, points: parseInt(pointsAmount) })
      });
      setSelectedCustomer('');
      setPointsAmount('');
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error adding points:', error);
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="admin-panel">
      <div className="ios-segmented-control">
        <button 
          className={activeTab === 'customers' ? 'active' : ''}
          onClick={() => setActiveTab('customers')}
        >
          Customers
        </button>
        <button 
          className={activeTab === 'points' ? 'active' : ''}
          onClick={() => setActiveTab('points')}
        >
          Add Points
        </button>
        <button 
          className={activeTab === 'stats' ? 'active' : ''}
          onClick={() => setActiveTab('stats')}
        >
          Statistics
        </button>
      </div>

      {activeTab === 'customers' && (
        <div className="ios-card">
          <h2>Customer Management</h2>
          <input
            className="ios-input"
            type="text"
            placeholder="Search customers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="customer-table">
            {filteredCustomers.map(customer => (
              <div key={customer.id} className="ios-list-row">
                <div className="customer-info">
                  <span className="customer-name">{customer.name}</span>
                  <span className="customer-email">{customer.email}</span>
                </div>
                <div className="customer-points">
                  {customer.points} points
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'points' && (
        <div className="ios-card">
          <h2>Add Points</h2>
          <select
            className="ios-input"
            value={selectedCustomer}
            onChange={(e) => setSelectedCustomer(e.target.value)}
          >
            <option value="">Select Customer</option>
            {customers.map(customer => (
              <option key={customer.id} value={customer.id}>
                {customer.name} ({customer.email})
              </option>
            ))}
          </select>
          <input
            className="ios-input"
            type="number"
            placeholder="Points amount"
            value={pointsAmount}
            onChange={(e) => setPointsAmount(e.target.value)}
          />
          <button className="ios-button-primary" onClick={addPoints}>
            Add Points
          </button>
        </div>
      )}

      {activeTab === 'stats' && (
        <div className="ios-card">
          <h2>Statistics</h2>
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-label">Total Customers</span>
              <span className="stat-value">{stats.totalCustomers}</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Total Points Distributed</span>
              <span className="stat-value">{stats.totalPoints}</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Average Points per Customer</span>
              <span className="stat-value">{stats.avgPoints}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;