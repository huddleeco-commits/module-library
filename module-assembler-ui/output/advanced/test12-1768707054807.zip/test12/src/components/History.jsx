import React, { useState } from 'react';

const History = () => {
  const [activeTab, setActiveTab] = useState('All');

  const transactions = [
    { id: 1, type: 'earned', description: 'Daily Login Bonus', points: 50, date: '2024-01-15', time: '09:30 AM' },
    { id: 2, type: 'spent', description: 'Free Coffee Redeemed', points: -500, date: '2024-01-14', time: '02:15 PM' },
    { id: 3, type: 'earned', description: 'Purchase at Store #123', points: 125, date: '2024-01-14', time: '11:45 AM' },
    { id: 4, type: 'earned', description: 'Referral Bonus', points: 200, date: '2024-01-13', time: '04:20 PM' },
    { id: 5, type: 'spent', description: '$5 Gift Card Redeemed', points: -1000, date: '2024-01-12', time: '01:30 PM' },
    { id: 6, type: 'earned', description: 'Survey Completion', points: 75, date: '2024-01-12', time: '10:15 AM' },
    { id: 7, type: 'earned', description: 'Weekly Challenge', points: 300, date: '2024-01-11', time: '06:45 PM' },
    { id: 8, type: 'spent', description: 'Free Lunch Redeemed', points: -800, date: '2024-01-10', time: '12:00 PM' }
  ];

  const filterTransactions = () => {
    switch(activeTab) {
      case 'Earned': return transactions.filter(t => t.type === 'earned');
      case 'Spent': return transactions.filter(t => t.type === 'spent');
      default: return transactions;
    }
  };

  const formatPoints = (points) => {
    return points > 0 ? `+${points}` : `${points}`;
  };

  return (
    <div className="history">
      <div className="history-header">
        <h2>Transaction History</h2>
      </div>

      <div className="ios-segmented-control">
        {['All', 'Earned', 'Spent'].map(tab => (
          <button
            key={tab}
            className={`segment ${activeTab === tab ? 'active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="history-list">
        {filterTransactions().map(transaction => (
          <div key={transaction.id} className="ios-list-row transaction-row">
            <div className="transaction-icon">
              <span className={`icon ${transaction.type}`}>
                {transaction.type === 'earned' ? '📈' : '🎁'}
              </span>
            </div>
            <div className="transaction-details">
              <div className="transaction-description">{transaction.description}</div>
              <div className="transaction-date">{transaction.date} at {transaction.time}</div>
            </div>
            <div className="transaction-points">
              <span className={`points ${transaction.type}`}>
                {formatPoints(transaction.points)} points
              </span>
            </div>
          </div>
        ))}
        
        {filterTransactions().length === 0 && (
          <div className="empty-state">
            <p>No transactions found for this filter.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default History;