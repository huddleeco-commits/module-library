import React from 'react';

function MemberCard({ user }) {
  const getTierColor = (tier) => {
    switch (tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const generateQRCode = (text) => {
    return (
      <div className="qr-placeholder">
        <div className="qr-grid">
          {Array.from({ length: 25 }).map((_, i) => (
            <div
              key={i}
              className="qr-pixel"
              style={{
                backgroundColor: Math.random() > 0.5 ? '#000' : 'transparent'
              }}
            ></div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="ios-card member-card">
      <div className="card-header">
        <h3>Member Card</h3>
        <span 
          className="ios-badge tier-badge"
          style={{ backgroundColor: getTierColor(user?.tier || 'Bronze') }}
        >
          {user?.tier || 'Bronze'}
        </span>
      </div>
      
      <div className="card-body">
        <div className="member-info">
          <h2>{user?.name || 'Member Name'}</h2>
          <p>Member since {new Date(user?.createdAt || Date.now()).getFullYear()}</p>
          <p className="member-id">ID: {user?.id || '000000'}</p>
        </div>
        
        <div className="qr-section">
          {generateQRCode(user?.id || '000000')}
          <p>Scan to earn points</p>
        </div>
      </div>
      
      <div className="card-footer">
        <div className="points-summary">
          <span className="points">{user?.points || 0} points</span>
        </div>
      </div>
    </div>
  );
}

export default MemberCard;