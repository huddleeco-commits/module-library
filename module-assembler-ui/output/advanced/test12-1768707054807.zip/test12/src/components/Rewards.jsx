import React, { useState } from 'react';

const Rewards = ({ userPoints = 1250 }) => {
  const [selectedReward, setSelectedReward] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const rewards = [
    { id: 1, name: 'Free Coffee', points: 500, image: '☕', available: true },
    { id: 2, name: '$5 Gift Card', points: 1000, image: '🎁', available: true },
    { id: 3, name: 'Premium Membership', points: 2000, image: '⭐', available: false },
    { id: 4, name: 'Free Lunch', points: 800, image: '🍽️', available: true },
    { id: 5, name: '$10 Gift Card', points: 2500, image: '💳', available: false },
    { id: 6, name: 'VIP Event Access', points: 1500, image: '🎫', available: false }
  ];

  const handleRedeem = (reward) => {
    setSelectedReward(reward);
    setShowModal(true);
  };

  const confirmRedeem = () => {
    setShowModal(false);
    setSelectedReward(null);
  };

  return (
    <div className="rewards">
      <div className="rewards-header">
        <h2>Rewards Store</h2>
        <div className="points-balance">
          <span>Available Points: {userPoints}</span>
        </div>
      </div>
      
      <div className="rewards-grid">
        {rewards.map(reward => (
          <div key={reward.id} className="ios-card reward-card">
            <div className="reward-image">{reward.image}</div>
            <div className="reward-info">
              <h3>{reward.name}</h3>
              <div className="reward-points">{reward.points} points</div>
            </div>
            <button 
              className={`ios-button-primary ${!reward.available ? 'disabled' : ''}`}
              onClick={() => handleRedeem(reward)}
              disabled={!reward.available || userPoints < reward.points}
            >
              {userPoints < reward.points ? 'Not Enough Points' : 'Redeem'}
            </button>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="ios-modal-sheet" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Confirm Redemption</h3>
              <button className="close-btn" onClick={() => setShowModal(false)}>×</button>
            </div>
            <div className="modal-content">
              <div className="reward-preview">
                <div className="reward-image-large">{selectedReward?.image}</div>
                <h3>{selectedReward?.name}</h3>
                <p>Cost: {selectedReward?.points} points</p>
                <p>Remaining: {userPoints - selectedReward?.points} points</p>
              </div>
            </div>
            <div className="modal-actions">
              <button className="ios-button-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="ios-button-primary" onClick={confirmRedeem}>Confirm Redeem</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rewards;