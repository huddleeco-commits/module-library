import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';

function App() {
  const { user, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');

  const mockRewards = [
    { id: 1, name: '10% Off', cost: 100, description: 'Next purchase' },
    { id: 2, name: 'Free Item', cost: 250, description: 'Select items' },
    { id: 3, name: '20% Off', cost: 500, description: 'Entire order' }
  ];

  const renderLogin = () => (
    <div className="p-4 space-y-4">
      <div className="ios-card">
        <h2 className="text-xl font-bold mb-4">Login</h2>
        <div className="space-y-3">
          <input type="email" placeholder="Email" className="w-full p-3 border rounded-lg" />
          <input type="password" placeholder="Password" className="w-full p-3 border rounded-lg" />
          <button className="ios-button w-full">Sign In</button>
        </div>
        <p className="text-center mt-4 text-gray-600">
          Don't have an account? 
          <button onClick={() => setCurrentPage('register')} className="text-blue-500 ml-1">Sign up</button>
        </p>
      </div>
    </div>
  );

  const renderRegister = () => (
    <div className="p-4 space-y-4">
      <div className="ios-card">
        <h2 className="text-xl font-bold mb-4">Sign Up</h2>
        <div className="space-y-3">
          <input type="text" placeholder="Full Name" className="w-full p-3 border rounded-lg" />
          <input type="email" placeholder="Email" className="w-full p-3 border rounded-lg" />
          <input type="password" placeholder="Password" className="w-full p-3 border rounded-lg" />
          <button className="ios-button w-full">Create Account</button>
        </div>
        <p className="text-center mt-4 text-gray-600">
          Already have an account? 
          <button onClick={() => setCurrentPage('login')} className="text-blue-500 ml-1">Sign in</button>
        </p>
      </div>
    </div>
  );

  const renderHome = () => (
    <div className="p-4 space-y-4">
      <div className="ios-card text-center">
        <h3 className="text-lg font-semibold text-gray-600">Points Balance</h3>
        <div className="text-4xl font-bold text-blue-500 my-2">{user?.points || 0}</div>
        <div className="ios-badge">Silver Member</div>
      </div>
      <div className="ios-card">
        <h4 className="font-semibold mb-2">Progress to Gold</h4>
        <div className="w-full bg-gray-200 rounded-full h-3">
          <div className="bg-blue-500 h-3 rounded-full" style={{width: '60%'}}></div>
        </div>
        <p className="text-sm text-gray-600 mt-2">150 more points to Gold</p>
      </div>
    </div>
  );

  const renderRewards = () => (
    <div className="p-4">
      <div className="grid gap-4">
        {mockRewards.map(reward => (
          <div key={reward.id} className="ios-card">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-semibold">{reward.name}</h3>
                <p className="text-gray-600 text-sm">{reward.description}</p>
              </div>
              <div className="text-right">
                <div className="font-bold text-blue-500">{reward.cost} pts</div>
                <button className="ios-button mt-2">Redeem</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCard = () => (
    <div className="p-4">
      <div className="ios-card text-center">
        <h3 className="text-xl font-bold mb-4">Member Card</h3>
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 rounded-lg mb-4">
          <div className="text-lg font-bold">{user?.name || 'Member'}</div>
          <div className="text-sm opacity-90">Silver Member</div>
          <div className="text-xs mt-2">ID: {user?.id || '12345'}</div>
        </div>
        <div className="w-32 h-32 bg-white border mx-auto mb-4 flex items-center justify-center">
          <div className="text-xs text-gray-400">QR Code</div>
        </div>
        <p className="text-sm text-gray-600">Show this card at checkout</p>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="p-4 space-y-4">
      <div className="ios-card">
        <div className="ios-list-row">Account Settings</div>
        <div className="ios-list-row">Transaction History</div>
        <div className="ios-list-row">Help & Support</div>
        <div className="ios-list-row">Privacy Policy</div>
      </div>
      <button onClick={logout} className="ios-button w-full bg-red-500 text-white">
        Logout
      </button>
    </div>
  );

  const renderContent = () => {
    if (!user) {
      return currentPage === 'register' ? renderRegister() : renderLogin();
    }
    
    switch(currentPage) {
      case 'rewards': return renderRewards();
      case 'card': return renderCard();
      case 'profile': return renderProfile();
      default: return renderHome();
    }
  };

  const getPageTitle = () => {
    if (!user) return currentPage === 'register' ? 'Sign Up' : 'Welcome';
    switch(currentPage) {
      case 'rewards': return 'Rewards';
      case 'card': return 'Member Card';
      case 'profile': return 'Profile';
      default: return 'test12';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="ios-nav-bar">
        <h1 className="ios-nav-title-large">{getPageTitle()}</h1>
      </div>
      
      <div className="pt-20 pb-20">
        {renderContent()}
      </div>

      {user && (
        <div className="ios-tab-bar">
          <div className={`ios-tab-item ${currentPage === 'home' ? 'active' : ''}`} onClick={() => setCurrentPage('home')}>
            <div className="text-xl mb-1">🏠</div>
            <span>Home</span>
          </div>
          <div className={`ios-tab-item ${currentPage === 'rewards' ? 'active' : ''}`} onClick={() => setCurrentPage('rewards')}>
            <div className="text-xl mb-1">🎁</div>
            <span>Rewards</span>
          </div>
          <div className={`ios-tab-item ${currentPage === 'card' ? 'active' : ''}`} onClick={() => setCurrentPage('card')}>
            <div className="text-xl mb-1">💳</div>
            <span>Card</span>
          </div>
          <div className={`ios-tab-item ${currentPage === 'profile' ? 'active' : ''}`} onClick={() => setCurrentPage('profile')}>
            <div className="text-xl mb-1">👤</div>
            <span>Profile</span>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;