import React, { useState, useEffect } from 'react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [pointsToAdd, setPointsToAdd] = useState('');
  const [stats, setStats] = useState({ totalCustomers: 0, totalPoints: 0, avgPoints: 0 });

  useEffect(() => {
    fetchCustomers();
    fetchStats();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch('/api/customers');
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const addPoints = async () => {
    if (!selectedCustomer || !pointsToAdd) return;
    
    try {
      await fetch('/api/add-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId: selectedCustomer, points: parseInt(pointsToAdd) })
      });
      
      setPointsToAdd('');
      setSelectedCustomer('');
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error adding points:', error);
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="admin-panel">
      <div className="ios-segmented-control">
        <button 
          className={activeTab === 'customers' ? 'active' : ''}
          onClick={() => setActiveTab('customers')}
        >
          Customers
        </button>
        <button 
          className={activeTab === 'add-points' ? 'active' : ''}
          onClick={() => setActiveTab('add-points')}
        >
          Add Points
        </button>
        <button 
          className={activeTab === 'stats' ? 'active' : ''}
          onClick={() => setActiveTab('stats')}
        >
          Statistics
        </button>
      </div>

      {activeTab === 'customers' && (
        <div className="ios-card">
          <h2>Customer Management</h2>
          <input 
            type="text"
            className="ios-input"
            placeholder="Search customers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          
          <div className="customer-table">
            {filteredCustomers.map(customer => (
              <div key={customer.id} className="ios-list-row">
                <div className="customer-info">
                  <span className="name">{customer.name}</span>
                  <span className="email">{customer.email}</span>
                </div>
                <div className="points">
                  {customer.points} points
                </div>
                <div className="joined">
                  {new Date(customer.created_at).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'add-points' && (
        <div className="ios-card">
          <h2>Add Points to Customer</h2>
          <div className="form-group">
            <label>Select Customer</label>
            <select 
              className="ios-input"
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
            >
              <option value="">Choose customer...</option>
              {customers.map(customer => (
                <option key={customer.id} value={customer.id}>
                  {customer.name} - {customer.email}
                </option>
              ))}
            </select>
          </div>
          
          <div className="form-group">
            <label>Points to Add</label>
            <input 
              type="number"
              className="ios-input"
              placeholder="Enter points amount"
              value={pointsToAdd}
              onChange={(e) => setPointsToAdd(e.target.value)}
            />
          </div>
          
          <button 
            className="ios-button-primary"
            onClick={addPoints}
            disabled={!selectedCustomer || !pointsToAdd}
          >
            Add Points
          </button>
        </div>
      )}

      {activeTab === 'stats' && (
        <div className="stats-container">
          <div className="ios-card">
            <h3>Total Customers</h3>
            <div className="stat-value">{stats.totalCustomers}</div>
          </div>
          
          <div className="ios-card">
            <h3>Total Points Issued</h3>
            <div className="stat-value">{stats.totalPoints}</div>
          </div>
          
          <div className="ios-card">
            <h3>Average Points per Customer</h3>
            <div className="stat-value">{stats.avgPoints}</div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;