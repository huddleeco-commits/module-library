import React from 'react';

const MemberCard = ({ user }) => {
  const { name = 'Member Name', tier = 'Bronze', memberId = '123456' } = user || {};
  
  const tiers = {
    Bronze: { color: '#CD7F32', gradient: 'linear-gradient(135deg, #CD7F32 0%, #8B4513 100%)' },
    Silver: { color: '#C0C0C0', gradient: 'linear-gradient(135deg, #C0C0C0 0%, #808080 100%)' },
    Gold: { color: '#FFD700', gradient: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)' },
    Platinum: { color: '#E5E4E2', gradient: 'linear-gradient(135deg, #E5E4E2 0%, #A9A9A9 100%)' }
  };
  
  const currentTier = tiers[tier];
  
  const generateQRCode = (text) => {
    return (
      <svg width="80" height="80" viewBox="0 0 25 25">
        {Array.from({ length: 625 }, (_, i) => {
          const x = i % 25;
          const y = Math.floor(i / 25);
          const hash = (text + x + y).split('').reduce((a, b) => ((a << 5) - a + b.charCodeAt(0)) & 0xffffffff, 0);
          return Math.abs(hash) % 3 === 0 ? (
            <rect key={i} x={x} y={y} width="1" height="1" fill="#000" />
          ) : null;
        })}
      </svg>
    );
  };

  return (
    <div className="member-card-container">
      <div className="ios-card member-card" style={{ background: currentTier.gradient }}>
        <div className="card-header">
          <div className="card-logo">
            <span style={{ color: '#fff', fontWeight: 'bold', fontSize: '18px' }}>LOYALTY</span>
          </div>
          <div className="ios-badge tier-badge" style={{ backgroundColor: 'rgba(255,255,255,0.2)', color: '#fff' }}>
            {tier}
          </div>
        </div>
        
        <div className="card-content">
          <div className="member-info">
            <div className="member-name" style={{ color: '#fff', fontSize: '20px', fontWeight: '600' }}>
              {name}
            </div>
            <div className="member-id" style={{ color: 'rgba(255,255,255,0.8)', fontSize: '14px' }}>
              ID: {memberId}
            </div>
          </div>
          
          <div className="qr-code">
            <div className="qr-container" style={{ backgroundColor: '#fff', padding: '8px', borderRadius: '8px' }}>
              {generateQRCode(memberId)}
            </div>
          </div>
        </div>
        
        <div className="card-footer" style={{ color: 'rgba(255,255,255,0.7)', fontSize: '12px' }}>
          Present this card for rewards
        </div>
      </div>
    </div>
  );
};

export default MemberCard;