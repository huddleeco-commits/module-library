import React from 'react';

const Dashboard = ({ user }) => {
  const { points = 0, tier = 'Bronze', name = 'Member' } = user || {};
  
  const tiers = {
    Bronze: { color: '#CD7F32', next: 'Silver', pointsNeeded: 1000 },
    Silver: { color: '#C0C0C0', next: 'Gold', pointsNeeded: 2500 },
    Gold: { color: '#FFD700', next: 'Platinum', pointsNeeded: 5000 },
    Platinum: { color: '#E5E4E2', next: null, pointsNeeded: 0 }
  };
  
  const currentTier = tiers[tier];
  const progress = currentTier.next ? (points / currentTier.pointsNeeded) * 100 : 100;
  const pointsToNext = currentTier.next ? Math.max(0, currentTier.pointsNeeded - points) : 0;

  return (
    <div className="dashboard">
      <div className="ios-card">
        <div className="dashboard-header">
          <h2>Hello, {name}!</h2>
          <div className="ios-badge" style={{ backgroundColor: currentTier.color, color: '#fff' }}>
            {tier}
          </div>
        </div>
        
        <div className="points-display">
          <div className="points-number">{points.toLocaleString()}</div>
          <div className="points-label">points</div>
        </div>
        
        {currentTier.next && (
          <div className="progress-section">
            <div className="progress-info">
              <span>{pointsToNext} points to {currentTier.next}</span>
            </div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ 
                  width: `${Math.min(progress, 100)}%`,
                  backgroundColor: tiers[currentTier.next].color
                }}
              />
            </div>
          </div>
        )}
        
        {tier === 'Platinum' && (
          <div className="platinum-status">
            <span>🎉 You've reached our highest tier!</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;