import React, { useState, useEffect } from 'react';

const History = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [transactions, setTransactions] = useState([]);
  const [filteredTransactions, setFilteredTransactions] = useState([]);

  useEffect(() => {
    fetchTransactions();
  }, []);

  useEffect(() => {
    filterTransactions();
  }, [activeTab, transactions]);

  const fetchTransactions = async () => {
    try {
      const response = await fetch('/api/transactions');
      const data = await response.json();
      setTransactions(data);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  };

  const filterTransactions = () => {
    if (activeTab === 'all') {
      setFilteredTransactions(transactions);
    } else {
      setFilteredTransactions(transactions.filter(t => t.type === activeTab));
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getTransactionIcon = (type) => {
    return type === 'earned' ? '+' : '-';
  };

  const getTransactionColor = (type) => {
    return type === 'earned' ? 'transaction-earned' : 'transaction-spent';
  };

  return (
    <div className="history-container">
      <div className="ios-segmented-control">
        <button 
          className={activeTab === 'all' ? 'active' : ''}
          onClick={() => setActiveTab('all')}
        >
          All
        </button>
        <button 
          className={activeTab === 'earned' ? 'active' : ''}
          onClick={() => setActiveTab('earned')}
        >
          Earned
        </button>
        <button 
          className={activeTab === 'spent' ? 'active' : ''}
          onClick={() => setActiveTab('spent')}
        >
          Spent
        </button>
      </div>
      
      <div className="transaction-list">
        {filteredTransactions.map(transaction => (
          <div key={transaction.id} className="ios-list-row">
            <div className="transaction-content">
              <div className="transaction-main">
                <h4>{transaction.description}</h4>
                <p className="transaction-date">{formatDate(transaction.date)}</p>
              </div>
              <div className={`transaction-amount ${getTransactionColor(transaction.type)}`}>
                <span className="transaction-sign">{getTransactionIcon(transaction.type)}</span>
                <span>{transaction.points} points</span>
              </div>
            </div>
          </div>
        ))}
        
        {filteredTransactions.length === 0 && (
          <div className="empty-state">
            <p>No transactions found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default History;