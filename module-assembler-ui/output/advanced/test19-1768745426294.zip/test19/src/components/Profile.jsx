import React from 'react';

const Profile = () => {
  const user = {
    name: 'John Doe',
    email: 'john.doe@email.com',
    tier: 'Gold',
    lifetimePoints: 12450,
    referralCode: 'JOHN2024'
  };

  const handleShareReferral = () => {
    navigator.clipboard.writeText(user.referralCode);
  };

  return (
    <div className="profile-container">
      <div className="ios-card">
        <div className="profile-header">
          <div className="avatar">
            <img src="https://via.placeholder.com/80" alt="Profile" />
          </div>
          <h2>{user.name}</h2>
          <span className="ios-badge ios-badge-gold">{user.tier}</span>
        </div>
      </div>

      <div className="ios-card">
        <div className="ios-list-row">
          <span className="label">Email</span>
          <span className="value">{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Tier Status</span>
          <span className="value">{user.tier}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Lifetime Points</span>
          <span className="value">{user.lifetimePoints.toLocaleString()} points</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Referral Code</span>
          <span className="value">{user.referralCode}</span>
        </div>
      </div>

      <div className="ios-card">
        <button className="ios-button ios-button-primary" onClick={handleShareReferral}>
          Share Referral Code
        </button>
      </div>
    </div>
  );
};

export default Profile;