import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';

function App() {
  const { user, login, register, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [registerData, setRegisterData] = useState({ name: '', email: '', password: '' });

  const handleLogin = async (e) => {
    e.preventDefault();
    await login(loginData.email, loginData.password);
    setCurrentPage('home');
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    await register(registerData.name, registerData.email, registerData.password);
    setCurrentPage('home');
  };

  const handleLogout = () => {
    logout();
    setCurrentPage('login');
  };

  if (!user) {
    if (currentPage === 'register') {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <div className="ios-card w-full max-w-md">
            <h2 className="text-2xl font-bold mb-6 text-center">Join test19</h2>
            <form onSubmit={handleRegister} className="space-y-4">
              <input
                type="text"
                placeholder="Full Name"
                className="w-full p-3 border rounded-lg"
                value={registerData.name}
                onChange={(e) => setRegisterData({...registerData, name: e.target.value})}
              />
              <input
                type="email"
                placeholder="Email"
                className="w-full p-3 border rounded-lg"
                value={registerData.email}
                onChange={(e) => setRegisterData({...registerData, email: e.target.value})}
              />
              <input
                type="password"
                placeholder="Password"
                className="w-full p-3 border rounded-lg"
                value={registerData.password}
                onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
              />
              <button type="submit" className="ios-button w-full">Create Account</button>
            </form>
            <p className="text-center mt-4">
              Already have an account? 
              <button className="text-blue-600 ml-1" onClick={() => setCurrentPage('login')}>Sign In</button>
            </p>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="ios-card w-full max-w-md">
          <h2 className="text-2xl font-bold mb-6 text-center">Welcome to test19</h2>
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="email"
              placeholder="Email"
              className="w-full p-3 border rounded-lg"
              value={loginData.email}
              onChange={(e) => setLoginData({...loginData, email: e.target.value})}
            />
            <input
              type="password"
              placeholder="Password"
              className="w-full p-3 border rounded-lg"
              value={loginData.password}
              onChange={(e) => setLoginData({...loginData, password: e.target.value})}
            />
            <button type="submit" className="ios-button w-full">Sign In</button>
          </form>
          <p className="text-center mt-4">
            Don't have an account? 
            <button className="text-blue-600 ml-1" onClick={() => setCurrentPage('register')}>Sign Up</button>
          </p>
        </div>
      </div>
    );
  }

  const renderHome = () => (
    <div className="p-4 space-y-4">
      <div className="ios-card">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-blue-600">{user.points || 0}</h2>
          <p className="text-gray-600">Total Points</p>
          <div className="ios-badge mt-2">{user.tier || 'Bronze'} Member</div>
        </div>
        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>Progress to Silver</span>
            <span>{user.points || 0}/500</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-blue-600 h-2 rounded-full" style={{width: `${Math.min(((user.points || 0) / 500) * 100, 100)}%`}}></div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderRewards = () => (
    <div className="p-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="ios-card text-center">
          <div className="text-2xl mb-2">☕</div>
          <h3 className="font-semibold">Free Coffee</h3>
          <p className="text-sm text-gray-600">100 points</p>
          <button className="ios-button mt-2 text-sm">Redeem</button>
        </div>
        <div className="ios-card text-center">
          <div className="text-2xl mb-2">🍔</div>
          <h3 className="font-semibold">Free Meal</h3>
          <p className="text-sm text-gray-600">250 points</p>
          <button className="ios-button mt-2 text-sm">Redeem</button>
        </div>
        <div className="ios-card text-center">
          <div className="text-2xl mb-2">🎁</div>
          <h3 className="font-semibold">Gift Card</h3>
          <p className="text-sm text-gray-600">500 points</p>
          <button className="ios-button mt-2 text-sm">Redeem</button>
        </div>
        <div className="ios-card text-center">
          <div className="text-2xl mb-2">⭐</div>
          <h3 className="font-semibold">VIP Access</h3>
          <p className="text-sm text-gray-600">1000 points</p>
          <button className="ios-button mt-2 text-sm">Redeem</button>
        </div>
      </div>
    </div>
  );

  const renderCard = () => (
    <div className="p-4">
      <div className="ios-card text-center">
        <h2 className="text-xl font-bold mb-2">{user.name}</h2>
        <p className="text-gray-600 mb-4">Member ID: {user.id}</p>
        <div className="bg-gray-100 p-8 rounded-lg mb-4">
          <div className="text-6xl">📱</div>
          <p className="text-sm text-gray-600 mt-2">QR Code</p>
        </div>
        <div className="ios-badge">{user.tier || 'Bronze'} Member</div>
        <p className="text-sm text-gray-600 mt-2">Show this card at checkout</p>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="p-4 space-y-4">
      <div className="ios-card">
        <div className="ios-list-row">
          <span>Name</span>
          <span className="text-gray-600">{user.name}</span>
        </div>
        <div className="ios-list-row">
          <span>Email</span>
          <span className="text-gray-600">{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span>Member Since</span>
          <span className="text-gray-600">{new Date(user.created_at).toLocaleDateString()}</span>
        </div>
        <div className="ios-list-row">
          <span>Tier</span>
          <span className="text-gray-600">{user.tier || 'Bronze'}</span>
        </div>
      </div>
      <button onClick={handleLogout} className="ios-button w-full bg-red-600">Sign Out</button>
    </div>
  );

  const renderContent = () => {
    switch(currentPage) {
      case 'home': return renderHome();
      case 'rewards': return renderRewards();
      case 'card': return renderCard();
      case 'profile': return renderProfile();
      default: return renderHome();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="ios-nav-bar">
        <h1 className="ios-nav-title-large">test19</h1>
      </div>
      
      <div className="pb-20">
        {renderContent()}
      </div>

      <div className="ios-tab-bar">
        <div 
          className={`ios-tab-item ${currentPage === 'home' ? 'active' : ''}`}
          onClick={() => setCurrentPage('home')}
        >
          <div className="text-xl">🏠</div>
          <span>Home</span>
        </div>
        <div 
          className={`ios-tab-item ${currentPage === 'rewards' ? 'active' : ''}`}
          onClick={() => setCurrentPage('rewards')}
        >
          <div className="text-xl">🎁</div>
          <span>Rewards</span>
        </div>
        <div 
          className={`ios-tab-item ${currentPage === 'card' ? 'active' : ''}`}
          onClick={() => setCurrentPage('card')}
        >
          <div className="text-xl">💳</div>
          <span>Card</span>
        </div>
        <div 
          className={`ios-tab-item ${currentPage === 'profile' ? 'active' : ''}`}
          onClick={() => setCurrentPage('profile')}
        >
          <div className="text-xl">👤</div>
          <span>Profile</span>
        </div>
      </div>
    </div>
  );
}

export default App;