# test11 Rewards

Premium loyalty program with testcoins rewards system.

## Quick Start

```bash
npm install
cp .env.example .env
npm run dev
```

Open http://localhost:5173

## Features
- 🎯 Testcoins earning & redemption
- 🏆 Tier system: Bronze → Silver → Gold → Platinum
- 🎁 Rewards catalog with 4 rewards
- 📱 Mobile-first PWA design
- 🔐 Secure authentication
- 👑 Admin dashboard
- 📊 Analytics & reporting

## Tier Benefits
- **Bronze**: 1x testcoins multiplier (0+ testcoins)\n- **Silver**: 1.25x testcoins multiplier (500+ testcoins)\n- **Gold**: 1.5x testcoins multiplier (2000+ testcoins)\n- **Platinum**: 2x testcoins multiplier (5000+ testcoins)