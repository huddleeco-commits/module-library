import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';

const App = () => {
  const { user, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');

  const mockRewards = [
    { id: 1, name: 'Free Coffee', cost: 100, description: 'Get a free coffee of your choice' },
    { id: 2, name: '20% Off', cost: 250, description: '20% off your next purchase' },
    { id: 3, name: 'Free Dessert', cost: 150, description: 'Free dessert with any meal' },
    { id: 4, name: '50% Off', cost: 500, description: '50% off your next order' }
  ];

  const getTier = (points) => {
    if (points < 100) return { name: 'Bronze', next: 'Silver', needed: 100 - points };
    if (points < 500) return { name: 'Silver', next: 'Gold', needed: 500 - points };
    return { name: 'Gold', next: null, needed: 0 };
  };

  const renderLogin = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center p-4">
      <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-8 w-full max-w-md">
        <h1 className="text-3xl font-bold text-white text-center mb-8">test11</h1>
        <div className="space-y-4">
          <button 
            onClick={() => setCurrentPage('register')}
            className="w-full bg-white/20 backdrop-blur text-white py-3 rounded-xl font-semibold"
          >
            Sign Up
          </button>
          <button 
            onClick={() => setCurrentPage('home')}
            className="w-full bg-purple-500 text-white py-3 rounded-xl font-semibold"
          >
            Sign In
          </button>
        </div>
      </div>
    </div>
  );

  const renderRegister = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center p-4">
      <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-8 w-full max-w-md">
        <h2 className="text-2xl font-bold text-white text-center mb-8">Create Account</h2>
        <div className="space-y-4">
          <input className="w-full bg-white/20 backdrop-blur text-white placeholder-white/70 py-3 px-4 rounded-xl" placeholder="Email" />
          <input className="w-full bg-white/20 backdrop-blur text-white placeholder-white/70 py-3 px-4 rounded-xl" placeholder="Password" type="password" />
          <button 
            onClick={() => setCurrentPage('home')}
            className="w-full bg-purple-500 text-white py-3 rounded-xl font-semibold"
          >
            Create Account
          </button>
          <button 
            onClick={() => setCurrentPage('login')}
            className="w-full text-white/80 py-2"
          >
            Back to Login
          </button>
        </div>
      </div>
    </div>
  );

  const renderHome = () => {
    const userPoints = 150;
    const tier = getTier(userPoints);
    return (
      <div className="pb-20 bg-gradient-to-br from-purple-600 to-blue-600 min-h-screen">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-white mb-6">Welcome to test11</h1>
          <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-6 mb-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-white mb-2">{userPoints}</div>
              <div className="text-white/80">testcoins</div>
            </div>
          </div>
          <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-white font-semibold">{tier.name} Member</div>
              <div className="bg-yellow-400 text-black px-3 py-1 rounded-full text-sm font-bold">{tier.name}</div>
            </div>
            {tier.next && (
              <div>
                <div className="text-white/80 text-sm mb-2">Progress to {tier.next}</div>
                <div className="bg-white/20 rounded-full h-2 mb-2">
                  <div className="bg-gradient-to-r from-yellow-400 to-orange-400 h-2 rounded-full" style={{width: `${((userPoints % 500) / (tier.name === 'Bronze' ? 100 : 500)) * 100}%`}}></div>
                </div>
                <div className="text-white/80 text-sm">{tier.needed} testcoins to go</div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderRewards = () => (
    <div className="pb-20 bg-gradient-to-br from-purple-600 to-blue-600 min-h-screen">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-white mb-6">Rewards</h1>
        <div className="grid grid-cols-1 gap-4">
          {mockRewards.map(reward => (
            <div key={reward.id} className="bg-white/20 backdrop-blur-lg rounded-2xl p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-white font-semibold">{reward.name}</h3>
                <div className="bg-yellow-400 text-black px-2 py-1 rounded-full text-sm font-bold">{reward.cost}</div>
              </div>
              <p className="text-white/80 text-sm mb-4">{reward.description}</p>
              <button className="bg-white/20 backdrop-blur text-white py-2 px-4 rounded-xl text-sm font-semibold w-full">
                Redeem
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCard = () => (
    <div className="pb-20 bg-gradient-to-br from-purple-600 to-blue-600 min-h-screen">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-white mb-6">Member Card</h1>
        <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-8">
          <div className="text-center">
            <h2 className="text-xl font-bold text-white mb-4">test11 Member</h2>
            <div className="bg-white/40 w-48 h-48 rounded-2xl mx-auto mb-4 flex items-center justify-center">
              <div className="text-white/80 font-semibold">QR Code</div>
            </div>
            <div className="text-white/80 mb-2">Member ID</div>
            <div className="text-white font-mono text-lg">#123456789</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="pb-20 bg-gradient-to-br from-purple-600 to-blue-600 min-h-screen">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-white mb-6">Profile</h1>
        <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-6 mb-6">
          <div className="text-center mb-6">
            <div className="w-20 h-20 bg-white/40 rounded-full mx-auto mb-4 flex items-center justify-center">
              <div className="text-white text-2xl font-bold">U</div>
            </div>
            <div className="text-white font-semibold text-lg">User Name</div>
            <div className="text-white/80">user@example.com</div>
          </div>
          <div className="space-y-4">
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-white/80 text-sm">Member Since</div>
              <div className="text-white font-semibold">January 2024</div>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <div className="text-white/80 text-sm">Total testcoins Earned</div>
              <div className="text-white font-semibold">1,250</div>
            </div>
          </div>
        </div>
        <button 
          onClick={() => setCurrentPage('login')}
          className="w-full bg-red-500/80 backdrop-blur text-white py-3 rounded-xl font-semibold"
        >
          Logout
        </button>
      </div>
    </div>
  );

  const BottomNav = () => (
    <div className="fixed bottom-0 left-0 right-0 bg-white/20 backdrop-blur-lg border-t border-white/20">
      <div className="flex justify-around py-2">
        {[
          { id: 'home', icon: '🏠', label: 'Home' },
          { id: 'rewards', icon: '🎁', label: 'Rewards' },
          { id: 'card', icon: '💳', label: 'Card' },
          { id: 'profile', icon: '👤', label: 'Profile' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setCurrentPage(tab.id)}
            className={`flex flex-col items-center py-2 px-4 ${currentPage === tab.id ? 'text-yellow-400' : 'text-white/80'}`}
          >
            <div className="text-xl mb-1">{tab.icon}</div>
            <div className="text-xs">{tab.label}</div>
          </button>
        ))}
      </div>
    </div>
  );

  if (currentPage === 'login') return renderLogin();
  if (currentPage === 'register') return renderRegister();

  return (
    <div className="min-h-screen bg-gray-100">
      {currentPage === 'home' && renderHome()}
      {currentPage === 'rewards' && renderRewards()}
      {currentPage === 'card' && renderCard()}
      {currentPage === 'profile' && renderProfile()}
      <BottomNav />
    </div>
  );
};

export default App;