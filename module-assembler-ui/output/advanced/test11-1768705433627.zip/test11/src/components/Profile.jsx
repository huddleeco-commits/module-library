import React, { useState, useEffect } from 'react';
import './Profile.css';

const Profile = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchUserProfile();
  }, []);

  const fetchUserProfile = async () => {
    try {
      const response = await fetch('/api/user/profile');
      const userData = await response.json();
      setUser(userData);
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyReferralCode = async () => {
    if (user?.referralCode) {
      await navigator.clipboard.writeText(user.referralCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const shareReferral = async () => {
    if (navigator.share && user?.referralCode) {
      await navigator.share({
        title: 'Join with my referral code',
        text: `Use my referral code: ${user.referralCode}`,
        url: window.location.origin
      });
    }
  };

  const getTierColor = (tier) => {
    switch (tier?.toLowerCase()) {
      case 'bronze': return '#CD7F32';
      case 'silver': return '#C0C0C0';
      case 'gold': return '#FFD700';
      case 'platinum': return '#E5E4E2';
      default: return '#6B7280';
    }
  };

  if (loading) {
    return <div className="profile-loading">Loading profile...</div>;
  }

  if (!user) {
    return <div className="profile-error">Failed to load profile</div>;
  }

  return (
    <div className="profile-container">
      <div className="profile-header">
        <div className="profile-avatar">
          {user.name?.charAt(0)?.toUpperCase()}
        </div>
        <div className="profile-info">
          <h1 className="profile-name">{user.name}</h1>
          <p className="profile-email">{user.email}</p>
        </div>
      </div>

      <div className="profile-stats">
        <div className="stat-card">
          <div className="tier-badge" style={{ backgroundColor: getTierColor(user.tier) }}>
            {user.tier || 'Bronze'}
          </div>
          <span className="stat-label">Current Tier</span>
        </div>

        <div className="stat-card">
          <div className="stat-value">
            {user.lifetimeTestcoins?.toLocaleString() || '0'}
          </div>
          <span className="stat-label">Lifetime Testcoins</span>
        </div>
      </div>

      <div className="referral-section">
        <h3 className="section-title">Referral Code</h3>
        <div className="referral-card">
          <div className="referral-code">
            {user.referralCode || 'NONE'}
          </div>
          <div className="referral-actions">
            <button 
              className={`copy-btn ${copied ? 'copied' : ''}`}
              onClick={copyReferralCode}
              disabled={!user.referralCode}
            >
              {copied ? 'Copied!' : 'Copy'}
            </button>
            <button 
              className="share-btn"
              onClick={shareReferral}
              disabled={!user.referralCode}
            >
              Share
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;