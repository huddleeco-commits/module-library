import React, { useState, useEffect } from 'react';
import './History.css';

const History = () => {
  const [transactions, setTransactions] = useState([]);
  const [activeTab, setActiveTab] = useState('all');
  const [filteredTransactions, setFilteredTransactions] = useState([]);

  useEffect(() => {
    fetchTransactions();
  }, []);

  useEffect(() => {
    filterTransactions();
  }, [transactions, activeTab]);

  const fetchTransactions = async () => {
    try {
      const response = await fetch('/api/transactions');
      const data = await response.json();
      setTransactions(data);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  };

  const filterTransactions = () => {
    let filtered = transactions;
    
    if (activeTab === 'earned') {
      filtered = transactions.filter(t => t.type === 'earn' && t.amount > 0);
    } else if (activeTab === 'spent') {
      filtered = transactions.filter(t => t.type === 'redeem' || t.amount < 0);
    }
    
    setFilteredTransactions(filtered);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTransactionIcon = (type) => {
    switch (type) {
      case 'earn': return '+';
      case 'redeem': return '-';
      case 'bonus': return '🎁';
      default: return '•';
    }
  };

  const getAmountClass = (amount, type) => {
    if (type === 'earn' || amount > 0) return 'amount positive';
    return 'amount negative';
  };

  return (
    <div className="history-container">
      <h2>Transaction History</h2>
      
      <div className="filter-tabs">
        <button 
          className={`tab ${activeTab === 'all' ? 'active' : ''}`}
          onClick={() => setActiveTab('all')}
        >
          All
        </button>
        <button 
          className={`tab ${activeTab === 'earned' ? 'active' : ''}`}
          onClick={() => setActiveTab('earned')}
        >
          Earned
        </button>
        <button 
          className={`tab ${activeTab === 'spent' ? 'active' : ''}`}
          onClick={() => setActiveTab('spent')}
        >
          Spent
        </button>
      </div>

      <div className="transaction-list">
        {filteredTransactions.length === 0 ? (
          <div className="empty-state">
            <p>No transactions found</p>
          </div>
        ) : (
          filteredTransactions.map(transaction => (
            <div key={transaction.id} className="transaction-item">
              <div className="transaction-icon">
                {getTransactionIcon(transaction.type)}
              </div>
              <div className="transaction-details">
                <div className="transaction-title">{transaction.description}</div>
                <div className="transaction-date">{formatDate(transaction.created_at)}</div>
              </div>
              <div className={getAmountClass(transaction.amount, transaction.type)}>
                {transaction.amount > 0 ? '+' : ''}{transaction.amount} testcoins
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default History;