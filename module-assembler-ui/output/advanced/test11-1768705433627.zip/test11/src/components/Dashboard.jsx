import React from 'react';

const Dashboard = ({ user }) => {
  const tierColors = {
    Bronze: '#CD7F32',
    Silver: '#C0C0C0',
    Gold: '#FFD700',
    Platinum: '#E5E4E2'
  };

  const tierThresholds = {
    Bronze: 0,
    Silver: 1000,
    Gold: 5000,
    Platinum: 10000
  };

  const getCurrentTier = (points) => {
    if (points >= 10000) return 'Platinum';
    if (points >= 5000) return 'Gold';
    if (points >= 1000) return 'Silver';
    return 'Bronze';
  };

  const getNextTier = (tier) => {
    const tiers = ['Bronze', 'Silver', 'Gold', 'Platinum'];
    const index = tiers.indexOf(tier);
    return index < 3 ? tiers[index + 1] : null;
  };

  const getProgress = (points, tier) => {
    const nextTier = getNextTier(tier);
    if (!nextTier) return 100;
    
    const current = tierThresholds[tier];
    const next = tierThresholds[nextTier];
    return ((points - current) / (next - current)) * 100;
  };

  const currentTier = getCurrentTier(user.points);
  const nextTier = getNextTier(currentTier);
  const progress = getProgress(user.points, currentTier);

  return (
    <div className="dashboard">
      <div className="welcome-card">
        <h1>Welcome, {user.name}!</h1>
        <div className="points-balance">
          <span className="points-number">{user.points.toLocaleString()}</span>
          <span className="points-label">testcoins</span>
        </div>
      </div>
      
      <div className="tier-card">
        <div className="tier-badge" style={{backgroundColor: tierColors[currentTier]}}>
          <span className="tier-name">{currentTier}</span>
          <span className="tier-icon">⭐</span>
        </div>
        
        {nextTier && (
          <div className="tier-progress">
            <div className="progress-info">
              <span>Progress to {nextTier}</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{width: `${progress}%`, backgroundColor: tierColors[nextTier]}}
              ></div>
            </div>
            <div className="points-needed">
              {tierThresholds[nextTier] - user.points} testcoins to {nextTier}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;