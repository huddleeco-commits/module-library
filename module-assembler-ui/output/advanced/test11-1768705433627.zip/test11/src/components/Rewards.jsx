import React, { useState, useEffect } from 'react';
import './Rewards.css';

const Rewards = () => {
  const [rewards, setRewards] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedReward, setSelectedReward] = useState(null);
  const [userBalance, setUserBalance] = useState(0);

  useEffect(() => {
    fetchRewards();
    fetchUserBalance();
  }, []);

  const fetchRewards = async () => {
    try {
      const response = await fetch('/api/rewards');
      const data = await response.json();
      setRewards(data);
    } catch (error) {
      console.error('Error fetching rewards:', error);
    }
  };

  const fetchUserBalance = async () => {
    try {
      const response = await fetch('/api/user/balance');
      const data = await response.json();
      setUserBalance(data.balance);
    } catch (error) {
      console.error('Error fetching balance:', error);
    }
  };

  const handleRedeemClick = (reward) => {
    setSelectedReward(reward);
    setShowModal(true);
  };

  const confirmRedeem = async () => {
    try {
      const response = await fetch('/api/rewards/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rewardId: selectedReward.id })
      });
      
      if (response.ok) {
        fetchUserBalance();
        setShowModal(false);
        alert('Reward redeemed successfully!');
      }
    } catch (error) {
      console.error('Error redeeming reward:', error);
    }
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedReward(null);
  };

  return (
    <div className="rewards-container">
      <div className="rewards-header">
        <h2>Available Rewards</h2>
        <div className="balance-display">
          Balance: {userBalance} testcoins
        </div>
      </div>
      
      <div className="rewards-grid">
        {rewards.map(reward => (
          <div key={reward.id} className="reward-card">
            <img src={reward.image} alt={reward.name} className="reward-image" />
            <h3>{reward.name}</h3>
            <p className="reward-description">{reward.description}</p>
            <div className="reward-cost">{reward.cost} testcoins</div>
            <button 
              className={`redeem-btn ${userBalance < reward.cost ? 'disabled' : ''}`}
              onClick={() => handleRedeemClick(reward)}
              disabled={userBalance < reward.cost}
            >
              {userBalance < reward.cost ? 'Insufficient Funds' : 'Redeem'}
            </button>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Confirm Redemption</h3>
            <p>Are you sure you want to redeem <strong>{selectedReward?.name}</strong> for {selectedReward?.cost} testcoins?</p>
            <div className="modal-actions">
              <button className="cancel-btn" onClick={closeModal}>Cancel</button>
              <button className="confirm-btn" onClick={confirmRedeem}>Confirm</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rewards;