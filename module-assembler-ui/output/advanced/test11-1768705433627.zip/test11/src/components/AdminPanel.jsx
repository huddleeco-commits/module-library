import React, { useState, useEffect } from 'react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [stats, setStats] = useState({ totalCustomers: 0, totalTestcoins: 0 });
  const [addCoinsForm, setAddCoinsForm] = useState({ customerId: '', amount: '' });

  useEffect(() => {
    fetchCustomers();
    fetchStats();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch('/api/customers');
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleAddTestcoins = async (e) => {
    e.preventDefault();
    try {
      await fetch('/api/add-testcoins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(addCoinsForm)
      });
      setAddCoinsForm({ customerId: '', amount: '' });
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error adding testcoins:', error);
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="admin-panel">
      <h1>Admin Panel</h1>
      
      <div className="tabs">
        <button 
          className={activeTab === 'customers' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('customers')}
        >
          Customers
        </button>
        <button 
          className={activeTab === 'add-coins' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('add-coins')}
        >
          Add Testcoins
        </button>
        <button 
          className={activeTab === 'stats' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('stats')}
        >
          Stats
        </button>
      </div>

      <div className="tab-content">
        {activeTab === 'customers' && (
          <div className="customers-tab">
            <input
              type="text"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
            <table className="customers-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Testcoins</th>
                  <th>Joined</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map(customer => (
                  <tr key={customer.id}>
                    <td>{customer.id}</td>
                    <td>{customer.name}</td>
                    <td>{customer.email}</td>
                    <td>{customer.testcoins}</td>
                    <td>{new Date(customer.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'add-coins' && (
          <div className="add-coins-tab">
            <form onSubmit={handleAddTestcoins} className="add-coins-form">
              <div className="form-group">
                <label>Customer ID:</label>
                <input
                  type="number"
                  value={addCoinsForm.customerId}
                  onChange={(e) => setAddCoinsForm({...addCoinsForm, customerId: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label>Testcoins Amount:</label>
                <input
                  type="number"
                  value={addCoinsForm.amount}
                  onChange={(e) => setAddCoinsForm({...addCoinsForm, amount: e.target.value})}
                  required
                />
              </div>
              <button type="submit" className="submit-btn">Add Testcoins</button>
            </form>
          </div>
        )}

        {activeTab === 'stats' && (
          <div className="stats-tab">
            <div className="stats-grid">
              <div className="stat-card">
                <h3>Total Customers</h3>
                <p className="stat-value">{stats.totalCustomers}</p>
              </div>
              <div className="stat-card">
                <h3>Total Testcoins Issued</h3>
                <p className="stat-value">{stats.totalTestcoins}</p>
              </div>
              <div className="stat-card">
                <h3>Average Testcoins per Customer</h3>
                <p className="stat-value">{stats.totalCustomers ? Math.round(stats.totalTestcoins / stats.totalCustomers) : 0}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        .admin-panel {
          max-width: 1200px;
          margin: 0 auto;
          padding: 20px;
          font-family: Arial, sans-serif;
        }
        
        .tabs {
          display: flex;
          border-bottom: 2px solid #ddd;
          margin-bottom: 20px;
        }
        
        .tab {
          padding: 12px 24px;
          border: none;
          background: none;
          cursor: pointer;
          border-bottom: 3px solid transparent;
          font-size: 16px;
        }
        
        .tab.active {
          border-bottom-color: #007bff;
          color: #007bff;
          font-weight: bold;
        }
        
        .search-input {
          width: 300px;
          padding: 10px;
          margin-bottom: 20px;
          border: 1px solid #ddd;
          border-radius: 4px;
        }
        
        .customers-table {
          width: 100%;
          border-collapse: collapse;
          background: white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .customers-table th,
        .customers-table td {
          padding: 12px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        
        .customers-table th {
          background: #f8f9fa;
          font-weight: bold;
        }
        
        .add-coins-form {
          max-width: 400px;
          background: white;
          padding: 30px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .form-group {
          margin-bottom: 20px;
        }
        
        .form-group label {
          display: block;
          margin-bottom: 5px;
          font-weight: bold;
        }
        
        .form-group input {
          width: 100%;
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 4px;
        }
        
        .submit-btn {
          background: #007bff;
          color: white;
          padding: 12px 24px;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 16px;
        }
        
        .submit-btn:hover {
          background: #0056b3;
        }
        
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 20px;
        }
        
        .stat-card {
          background: white;
          padding: 30px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          text-align: center;
        }
        
        .stat-card h3 {
          margin: 0 0 15px 0;
          color: #666;
        }
        
        .stat-value {
          font-size: 2.5em;
          font-weight: bold;
          color: #007bff;
          margin: 0;
        }
      `}</style>
    </div>
  );
};

export default AdminPanel;