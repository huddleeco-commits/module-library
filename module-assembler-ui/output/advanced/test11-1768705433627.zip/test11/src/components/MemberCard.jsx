import React from 'react';

const MemberCard = ({ user }) => {
  const tierColors = {
    Bronze: '#CD7F32',
    Silver: '#C0C0C0',
    Gold: '#FFD700',
    Platinum: '#E5E4E2'
  };

  const getCurrentTier = (points) => {
    if (points >= 10000) return 'Platinum';
    if (points >= 5000) return 'Gold';
    if (points >= 1000) return 'Silver';
    return 'Bronze';
  };

  const currentTier = getCurrentTier(user.points);
  const memberNumber = user.id.toString().padStart(8, '0');

  return (
    <div className="member-card-container">
      <div 
        className="member-card"
        style={{
          background: `linear-gradient(135deg, ${tierColors[currentTier]}40, ${tierColors[currentTier]}20)`,
          border: `2px solid ${tierColors[currentTier]}60`
        }}
      >
        <div className="card-header">
          <div className="card-logo">LOYALTY</div>
          <div className="card-tier">{currentTier}</div>
        </div>
        
        <div className="card-content">
          <div className="member-info">
            <div className="member-name">{user.name}</div>
            <div className="member-id">#{memberNumber}</div>
          </div>
          
          <div className="qr-placeholder">
            <div className="qr-code">
              <div className="qr-grid">
                {Array.from({length: 25}, (_, i) => (
                  <div 
                    key={i} 
                    className={`qr-pixel ${Math.random() > 0.5 ? 'filled' : ''}`}
                  ></div>
                ))}
              </div>
            </div>
            <div className="qr-label">Scan to earn points</div>
          </div>
        </div>
        
        <div className="card-footer">
          <div className="points-display">
            <span className="points">{user.points.toLocaleString()}</span>
            <span className="currency">testcoins</span>
          </div>
          <div className="card-valid">Member since {new Date(user.createdAt).getFullYear()}</div>
        </div>
      </div>
    </div>
  );
};

export default MemberCard;