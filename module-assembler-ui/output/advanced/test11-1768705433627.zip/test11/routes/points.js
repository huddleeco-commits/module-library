const express = require('express');
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const tiers = {
  Bronze: { min: 0, multiplier: 1 },
  Silver: { min: 500, multiplier: 1.25 },
  Gold: { min: 2000, multiplier: 1.5 },
  Platinum: { min: 5000, multiplier: 2 }
};

const calculateTier = (points) => {
  if (points >= 5000) return 'Platinum';
  if (points >= 2000) return 'Gold';
  if (points >= 500) return 'Silver';
  return 'Bronze';
};

router.use(verifyToken);

router.get('/balance', async (req, res) => {
  try {
    const result = await pool.query('SELECT points, tier FROM users WHERE id = $1', [req.user.id]);
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get balance' });
  }
});

router.get('/history', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get history' });
  }
});

router.post('/earn', async (req, res) => {
  try {
    const { amount, description = 'Points earned' } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }
    
    const userResult = await pool.query('SELECT points FROM users WHERE id = $1', [req.user.id]);
    const currentPoints = userResult.rows[0].points;
    const newPoints = currentPoints + amount;
    const newTier = calculateTier(newPoints);
    
    await pool.query('BEGIN');
    
    await pool.query('UPDATE users SET points = $1, tier = $2 WHERE id = $3', [newPoints, newTier, req.user.id]);
    
    await pool.query(
      'INSERT INTO transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [req.user.id, 'earn', amount, description, newPoints]
    );
    
    await pool.query('COMMIT');
    
    res.json({ points: newPoints, tier: newTier });
  } catch (error) {
    await pool.query('ROLLBACK');
    res.status(500).json({ error: 'Failed to earn points' });
  }
});

router.post('/spend', async (req, res) => {
  try {
    const { amount, description = 'Points spent' } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }
    
    const userResult = await pool.query('SELECT points FROM users WHERE id = $1', [req.user.id]);
    const currentPoints = userResult.rows[0].points;
    
    if (currentPoints < amount) {
      return res.status(400).json({ error: 'Insufficient points' });
    }
    
    const newPoints = currentPoints - amount;
    const newTier = calculateTier(newPoints);
    
    await pool.query('BEGIN');
    
    await pool.query('UPDATE users SET points = $1, tier = $2 WHERE id = $3', [newPoints, newTier, req.user.id]);
    
    await pool.query(
      'INSERT INTO transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [req.user.id, 'spend', amount, description, newPoints]
    );
    
    await pool.query('COMMIT');
    
    res.json({ points: newPoints, tier: newTier });
  } catch (error) {
    await pool.query('ROLLBACK');
    res.status(500).json({ error: 'Failed to spend points' });
  }
});

module.exports = router;