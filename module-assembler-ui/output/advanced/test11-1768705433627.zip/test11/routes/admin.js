const express = require('express');
const { Pool } = require('pg');
const { verifyToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

router.use(verifyToken);
router.use(requireAdmin);

router.get('/customers', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, email, name, points, tier, created_at FROM users WHERE is_admin = false ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get customers' });
  }
});

router.get('/stats', async (req, res) => {
  try {
    const totalCustomers = await pool.query('SELECT COUNT(*) FROM users WHERE is_admin = false');
    const totalPoints = await pool.query('SELECT SUM(points) FROM users WHERE is_admin = false');
    const totalRedemptions = await pool.query('SELECT COUNT(*) FROM redemptions');
    const tierStats = await pool.query(
      'SELECT tier, COUNT(*) as count FROM users WHERE is_admin = false GROUP BY tier'
    );
    
    res.json({
      totalCustomers: parseInt(totalCustomers.rows[0].count),
      totalPoints: parseInt(totalPoints.rows[0].sum) || 0,
      totalRedemptions: parseInt(totalRedemptions.rows[0].count),
      tierDistribution: tierStats.rows
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

router.post('/:id/points', async (req, res) => {
  try {
    const userId = req.params.id;
    const { amount, description = 'Admin adjustment' } = req.body;
    
    if (!amount || isNaN(amount)) {
      return res.status(400).json({ error: 'Invalid amount' });
    }
    
    const userResult = await pool.query('SELECT points FROM users WHERE id = $1 AND is_admin = false', [userId]);
    
    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    
    const currentPoints = userResult.rows[0].points;
    const newPoints = Math.max(0, currentPoints + amount);
    
    const calculateTier = (points) => {
      if (points >= 5000) return 'Platinum';
      if (points >= 2000) return 'Gold';
      if (points >= 500) return 'Silver';
      return 'Bronze';
    };
    
    const newTier = calculateTier(newPoints);
    
    await pool.query('BEGIN');
    
    await pool.query('UPDATE users SET points = $1, tier = $2 WHERE id = $3', [newPoints, newTier, userId]);
    
    await pool.query(
      'INSERT INTO transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [userId, amount > 0 ? 'earn' : 'spend', Math.abs(amount), description, newPoints]
    );
    
    await pool.query('COMMIT');
    
    res.json({ points: newPoints, tier: newTier });
  } catch (error) {
    await pool.query('ROLLBACK');
    res.status(500).json({ error: 'Failed to adjust points' });
  }
});

module.exports = router;