const express = require('express');
const QRCode = require('qrcode');
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

router.get('/member/:id', async (req, res) => {
  try {
    const userId = req.params.id;
    
    const result = await pool.query('SELECT id, email, name FROM users WHERE id = $1', [userId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Member not found' });
    }
    
    const qrData = JSON.stringify({
      memberId: userId,
      business: 'test11',
      timestamp: Date.now()
    });
    
    const qrCode = await QRCode.toBuffer(qrData, {
      type: 'png',
      width: 200,
      margin: 2
    });
    
    res.set('Content-Type', 'image/png');
    res.send(qrCode);
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate QR code' });
  }
});

router.post('/scan', verifyToken, async (req, res) => {
  try {
    const { qrData } = req.body;
    
    if (!qrData) {
      return res.status(400).json({ error: 'QR data required' });
    }
    
    let parsed;
    try {
      parsed = JSON.parse(qrData);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid QR code format' });
    }
    
    if (parsed.business !== 'test11') {
      return res.status(400).json({ error: 'Invalid business QR code' });
    }
    
    const timeDiff = Date.now() - parsed.timestamp;
    if (timeDiff > 300000) {
      return res.status(400).json({ error: 'QR code expired' });
    }
    
    const result = await pool.query(
      'SELECT id, email, name, points, tier FROM users WHERE id = $1',
      [parsed.memberId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Member not found' });
    }
    
    res.json({ member: result.rows[0], valid: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to verify member' });
  }
});

module.exports = router;