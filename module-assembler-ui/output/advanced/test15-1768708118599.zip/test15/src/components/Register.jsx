import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Register({ onLogin }) {
  const { register } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    const result = await register({ name, email, password, referralCode });
    setLoading(false);

    if (!result.success) {
      setError(result.error || 'Registration failed');
    }
  };

  return (
    <div className="page-content p-4">
      <div className="ios-card p-4">
        <h1 className="ios-large-title mb-6">Create Account</h1>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="ios-label">Name</label>
            <input
              type="text"
              className="ios-input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              required
              autoComplete="name"
            />
          </div>

          <div className="mb-4">
            <label className="ios-label">Email</label>
            <input
              type="email"
              className="ios-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
              autoComplete="email"
            />
          </div>

          <div className="mb-4">
            <label className="ios-label">Password</label>
            <input
              type="password"
              className="ios-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="At least 6 characters"
              required
              autoComplete="new-password"
            />
          </div>

          <div className="mb-4">
            <label className="ios-label">Referral Code (Optional)</label>
            <input
              type="text"
              className="ios-input"
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value)}
              placeholder="Enter referral code"
            />
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="ios-btn ios-btn-primary mb-4"
            disabled={loading}
          >
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-secondary">
          Already have an account?{' '}
          <button
            type="button"
            onClick={onLogin}
            className="ios-btn-text"
          >
            Sign In
          </button>
        </p>
      </div>
    </div>
  );
}
