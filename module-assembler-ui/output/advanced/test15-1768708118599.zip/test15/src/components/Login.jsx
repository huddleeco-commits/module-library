import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Login({ onRegister }) {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await login(email, password);
    setLoading(false);

    if (!result.success) {
      setError(result.error || 'Login failed');
    }
  };

  return (
    <div className="page-content p-4">
      <div className="ios-card p-4">
        <h1 className="ios-large-title mb-6">Sign In</h1>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="ios-label">Email</label>
            <input
              type="email"
              className="ios-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
              autoComplete="email"
            />
          </div>

          <div className="mb-4">
            <label className="ios-label">Password</label>
            <input
              type="password"
              className="ios-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              required
              autoComplete="current-password"
            />
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="ios-btn ios-btn-primary mb-4"
            disabled={loading}
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <p className="text-center text-secondary">
          Don't have an account?{' '}
          <button
            type="button"
            onClick={onRegister}
            className="ios-btn-text"
          >
            Register
          </button>
        </p>
      </div>
    </div>
  );
}
