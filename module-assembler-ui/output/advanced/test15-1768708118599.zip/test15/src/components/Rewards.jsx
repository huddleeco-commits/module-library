import React, { useState } from 'react';

const Rewards = () => {
  const [selectedReward, setSelectedReward] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const rewards = [
    { id: 1, title: '10% Off Coffee', cost: 500, description: 'Valid for 30 days' },
    { id: 2, title: 'Free Pastry', cost: 750, description: 'Any pastry item' },
    { id: 3, title: 'Buy 1 Get 1 Free', cost: 1000, description: 'Coffee beverages only' },
    { id: 4, title: '$5 Off Purchase', cost: 1250, description: 'Minimum $20 order' },
    { id: 5, title: 'Free Coffee', cost: 1500, description: 'Any size, any type' },
    { id: 6, title: '20% Off Total', cost: 2000, description: 'Valid for 14 days' }
  ];

  const handleRedeem = (reward) => {
    setSelectedReward(reward);
    setShowModal(true);
  };

  const confirmRedeem = () => {
    setShowModal(false);
    setSelectedReward(null);
  };

  return (
    <div className="rewards">
      <div className="rewards-grid">
        {rewards.map(reward => (
          <div key={reward.id} className="ios-card">
            <h3>{reward.title}</h3>
            <p className="reward-description">{reward.description}</p>
            <div className="reward-cost">{reward.cost} points</div>
            <button 
              className="ios-button-primary"
              onClick={() => handleRedeem(reward)}
            >
              Redeem
            </button>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="ios-modal-sheet">
          <div className="modal-content">
            <h2>Confirm Redemption</h2>
            <p>Redeem {selectedReward?.title} for {selectedReward?.cost} points?</p>
            <div className="modal-actions">
              <button 
                className="ios-button-primary"
                onClick={confirmRedeem}
              >
                Confirm
              </button>
              <button 
                className="cancel-button"
                onClick={() => setShowModal(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rewards;