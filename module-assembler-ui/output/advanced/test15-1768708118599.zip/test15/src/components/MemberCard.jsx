import React from 'react';

const MemberCard = ({ user }) => {
  const getTierColor = (tier) => {
    switch(tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const generateQRCode = () => {
    return (
      <svg width="80" height="80" viewBox="0 0 80 80">
        <rect width="80" height="80" fill="white"/>
        {[...Array(8)].map((_, i) => 
          [...Array(8)].map((_, j) => 
            (i + j) % 2 === 0 ? (
              <rect key={`${i}-${j}`} x={i*10} y={j*10} width="10" height="10" fill="black"/>
            ) : null
          )
        )}
      </svg>
    );
  };

  return (
    <div className="ios-card" style={{margin: '20px', padding: '0', background: `linear-gradient(135deg, ${getTierColor(user?.tier)}22 0%, ${getTierColor(user?.tier)}44 100%)`, border: `1px solid ${getTierColor(user?.tier)}33`}}>
      <div style={{padding: '24px'}}>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px'}}>
          <div>
            <h2 style={{fontSize: '24px', fontWeight: 'bold', margin: '0 0 8px', color: '#1D1D1F'}}>Member Card</h2>
            <div className="ios-badge" style={{backgroundColor: getTierColor(user?.tier), color: '#fff', fontWeight: '600'}}>
              {user?.tier || 'Bronze'} Member
            </div>
          </div>
          <div style={{backgroundColor: 'white', padding: '8px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)'}}>
            {generateQRCode()}
          </div>
        </div>
        
        <div style={{marginTop: 'auto'}}>
          <p style={{fontSize: '18px', fontWeight: '600', margin: '0', color: '#1D1D1F'}}>
            {user?.name || 'Member Name'}
          </p>
          <p style={{fontSize: '14px', color: '#86868B', margin: '4px 0 0'}}>
            Member ID: {user?.id?.toString().padStart(8, '0') || '00000001'}
          </p>
        </div>
      </div>
      
      <div style={{borderTop: '1px solid rgba(0,0,0,0.1)', padding: '16px 24px', backgroundColor: 'rgba(255,255,255,0.5)'}}>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
          <div>
            <p style={{fontSize: '14px', color: '#86868B', margin: '0'}}>Current Points</p>
            <p style={{fontSize: '20px', fontWeight: 'bold', margin: '0', color: '#1D1D1F'}}>
              {user?.points?.toLocaleString() || '0'}
            </p>
          </div>
          <div style={{fontSize: '12px', color: '#86868B', textAlign: 'right'}}>
            <p style={{margin: '0'}}>Scan at checkout</p>
            <p style={{margin: '0'}}>to earn points</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MemberCard;