import React, { useState } from 'react';

function Profile() {
  const [user] = useState({
    name: 'John Smith',
    email: 'john.smith@email.com',
    tier: 'Gold',
    lifetimePoints: 12450,
    referralCode: 'JS2024X7'
  });

  const handleShareReferral = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join with my referral code',
        text: `Use my referral code: ${user.referralCode}`,
        url: window.location.origin
      });
    } else {
      navigator.clipboard.writeText(user.referralCode);
      alert('Referral code copied!');
    }
  };

  return (
    <div className="profile-page">
      <div className="ios-card">
        <div className="profile-header">
          <div className="avatar">
            <img src="/api/placeholder/80/80" alt="Profile" />
          </div>
          <div className="user-info">
            <h2>{user.name}</h2>
            <div className="ios-badge ios-badge-gold">{user.tier}</div>
          </div>
        </div>
      </div>

      <div className="ios-card">
        <div className="ios-list-row">
          <span className="label">Name</span>
          <span className="value">{user.name}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Email</span>
          <span className="value">{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Tier</span>
          <span className="value">
            <div className="ios-badge ios-badge-gold">{user.tier}</div>
          </span>
        </div>
        <div className="ios-list-row">
          <span className="label">Lifetime Points</span>
          <span className="value">{user.lifetimePoints.toLocaleString()} points</span>
        </div>
      </div>

      <div className="ios-card">
        <div className="ios-list-row">
          <span className="label">Referral Code</span>
          <span className="value referral-code">{user.referralCode}</span>
        </div>
        <button className="ios-button ios-button-primary" onClick={handleShareReferral}>
          Share Referral Code
        </button>
      </div>
    </div>
  );
}

export default Profile;