import React, { useState } from 'react';

const History = () => {
  const [selectedTab, setSelectedTab] = useState('All');

  const transactions = [
    { id: 1, type: 'earned', amount: 50, description: 'Purchase at Store #1', date: '2024-01-15' },
    { id: 2, type: 'spent', amount: -500, description: '10% Off Coffee', date: '2024-01-14' },
    { id: 3, type: 'earned', amount: 75, description: 'Purchase at Store #2', date: '2024-01-13' },
    { id: 4, type: 'earned', amount: 100, description: 'Bonus Points', date: '2024-01-12' },
    { id: 5, type: 'spent', amount: -750, description: 'Free Pastry', date: '2024-01-11' },
    { id: 6, type: 'earned', amount: 25, description: 'Purchase at Store #1', date: '2024-01-10' }
  ];

  const filteredTransactions = transactions.filter(transaction => {
    if (selectedTab === 'All') return true;
    if (selectedTab === 'Earned') return transaction.type === 'earned';
    if (selectedTab === 'Spent') return transaction.type === 'spent';
    return true;
  });

  return (
    <div className="history">
      <div className="ios-segmented-control">
        {['All', 'Earned', 'Spent'].map(tab => (
          <button
            key={tab}
            className={selectedTab === tab ? 'active' : ''}
            onClick={() => setSelectedTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="transaction-list">
        {filteredTransactions.map(transaction => (
          <div key={transaction.id} className="ios-list-row">
            <div className="transaction-info">
              <div className="transaction-description">{transaction.description}</div>
              <div className="transaction-date">{transaction.date}</div>
            </div>
            <div className={`transaction-amount ${transaction.type}`}>
              {transaction.amount > 0 ? '+' : ''}{transaction.amount} points
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default History;