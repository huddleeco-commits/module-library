import React, { useState, useEffect } from 'react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [pointsToAdd, setPointsToAdd] = useState('');
  const [stats, setStats] = useState({ totalCustomers: 0, totalPoints: 0, avgPoints: 0 });

  useEffect(() => {
    fetchCustomers();
    fetchStats();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch('/api/customers');
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleAddPoints = async (e) => {
    e.preventDefault();
    if (!selectedCustomer || !pointsToAdd) return;
    
    try {
      await fetch('/api/add-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId: selectedCustomer, points: parseInt(pointsToAdd) })
      });
      setPointsToAdd('');
      setSelectedCustomer('');
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error adding points:', error);
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderCustomersTab = () => (
    <div>
      <div className="ios-input" style={{ marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Search customers..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <div className="ios-card">
        <div className="ios-list-row" style={{ fontWeight: '600', borderBottom: '1px solid #e5e5e7' }}>
          <div style={{ flex: '2' }}>Name</div>
          <div style={{ flex: '2' }}>Email</div>
          <div style={{ flex: '1' }}>Points</div>
        </div>
        {filteredCustomers.map(customer => (
          <div key={customer.id} className="ios-list-row">
            <div style={{ flex: '2' }}>{customer.name}</div>
            <div style={{ flex: '2' }}>{customer.email}</div>
            <div style={{ flex: '1' }}>{customer.points} pts</div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAddPointsTab = () => (
    <div className="ios-card">
      <h3 style={{ marginBottom: '20px' }}>Add Points to Customer</h3>
      <form onSubmit={handleAddPoints}>
        <div style={{ marginBottom: '15px' }}>
          <label style={{ display: 'block', marginBottom: '5px' }}>Select Customer</label>
          <select 
            value={selectedCustomer} 
            onChange={(e) => setSelectedCustomer(e.target.value)}
            style={{ width: '100%', padding: '12px', border: '1px solid #d1d1d6', borderRadius: '10px' }}
          >
            <option value="">Choose customer...</option>
            {customers.map(customer => (
              <option key={customer.id} value={customer.id}>
                {customer.name} - {customer.email}
              </option>
            ))}
          </select>
        </div>
        <div className="ios-input" style={{ marginBottom: '20px' }}>
          <input
            type="number"
            placeholder="Points to add"
            value={pointsToAdd}
            onChange={(e) => setPointsToAdd(e.target.value)}
          />
        </div>
        <button type="submit" className="ios-button-primary">
          Add Points
        </button>
      </form>
    </div>
  );

  const renderStatsTab = () => (
    <div>
      <div className="ios-card" style={{ marginBottom: '20px' }}>
        <h3>Total Customers</h3>
        <div style={{ fontSize: '2rem', fontWeight: '600', color: '#007AFF' }}>
          {stats.totalCustomers}
        </div>
      </div>
      <div className="ios-card" style={{ marginBottom: '20px' }}>
        <h3>Total Points Distributed</h3>
        <div style={{ fontSize: '2rem', fontWeight: '600', color: '#34C759' }}>
          {stats.totalPoints} pts
        </div>
      </div>
      <div className="ios-card">
        <h3>Average Points per Customer</h3>
        <div style={{ fontSize: '2rem', fontWeight: '600', color: '#FF9500' }}>
          {Math.round(stats.avgPoints)} pts
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '30px' }}>Admin Panel</h1>
      
      <div className="ios-segmented-control" style={{ marginBottom: '30px' }}>
        <button 
          className={activeTab === 'customers' ? 'active' : ''}
          onClick={() => setActiveTab('customers')}
        >
          Customers
        </button>
        <button 
          className={activeTab === 'addpoints' ? 'active' : ''}
          onClick={() => setActiveTab('addpoints')}
        >
          Add Points
        </button>
        <button 
          className={activeTab === 'stats' ? 'active' : ''}
          onClick={() => setActiveTab('stats')}
        >
          Statistics
        </button>
      </div>

      {activeTab === 'customers' && renderCustomersTab()}
      {activeTab === 'addpoints' && renderAddPointsTab()}
      {activeTab === 'stats' && renderStatsTab()}
    </div>
  );
};

export default AdminPanel;