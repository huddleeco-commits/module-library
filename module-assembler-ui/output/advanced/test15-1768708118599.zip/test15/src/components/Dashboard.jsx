import React from 'react';

const Dashboard = ({ user }) => {
  const getTierColor = (tier) => {
    switch(tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const getNextTier = (tier) => {
    const tiers = ['Bronze', 'Silver', 'Gold', 'Platinum'];
    const currentIndex = tiers.indexOf(tier);
    return currentIndex < tiers.length - 1 ? tiers[currentIndex + 1] : null;
  };

  const getTierThresholds = () => ({ Bronze: 0, Silver: 1000, Gold: 5000, Platinum: 15000 });

  const calculateProgress = () => {
    const thresholds = getTierThresholds();
    const nextTier = getNextTier(user?.tier);
    if (!nextTier) return 100;
    
    const current = thresholds[user?.tier] || 0;
    const next = thresholds[nextTier];
    const progress = ((user?.points - current) / (next - current)) * 100;
    return Math.max(0, Math.min(100, progress));
  };

  const pointsToNext = () => {
    const thresholds = getTierThresholds();
    const nextTier = getNextTier(user?.tier);
    if (!nextTier) return 0;
    return thresholds[nextTier] - user?.points;
  };

  return (
    <div className="ios-card" style={{margin: '20px', padding: '24px'}}>
      <div style={{textAlign: 'center', marginBottom: '24px'}}>
        <h1 style={{fontSize: '48px', fontWeight: 'bold', margin: '0', color: '#1D1D1F'}}>
          {user?.points?.toLocaleString() || '0'}
        </h1>
        <p style={{fontSize: '18px', color: '#86868B', margin: '4px 0 16px'}}>points</p>
        
        <div className="ios-badge" style={{backgroundColor: getTierColor(user?.tier), color: '#fff', fontWeight: '600'}}>
          {user?.tier || 'Bronze'}
        </div>
      </div>

      {getNextTier(user?.tier) && (
        <div>
          <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: '8px'}}>
            <span style={{fontSize: '14px', color: '#86868B'}}>Progress to {getNextTier(user?.tier)}</span>
            <span style={{fontSize: '14px', color: '#86868B'}}>{pointsToNext()} points to go</span>
          </div>
          <div style={{width: '100%', height: '6px', backgroundColor: '#F2F2F7', borderRadius: '3px', overflow: 'hidden'}}>
            <div style={{width: `${calculateProgress()}%`, height: '100%', backgroundColor: getTierColor(getNextTier(user?.tier)), borderRadius: '3px', transition: 'width 0.3s ease'}}></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;