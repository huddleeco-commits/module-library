import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';

function App() {
  const { user, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="ios-nav-bar">
          <h1 className="ios-nav-title-large">test15</h1>
        </div>
        
        {currentPage === 'login' ? (
          <div className="ios-card mt-6">
            <h2 className="text-xl font-semibold mb-4">Sign In</h2>
            <form className="space-y-4">
              <input type="email" placeholder="Email" className="w-full p-3 border border-gray-200 rounded-lg" />
              <input type="password" placeholder="Password" className="w-full p-3 border border-gray-200 rounded-lg" />
              <button className="ios-button w-full">Sign In</button>
            </form>
            <p className="mt-4 text-center">
              Don't have an account? 
              <button onClick={() => setCurrentPage('register')} className="text-blue-500 ml-1">Sign Up</button>
            </p>
          </div>
        ) : (
          <div className="ios-card mt-6">
            <h2 className="text-xl font-semibold mb-4">Create Account</h2>
            <form className="space-y-4">
              <input type="text" placeholder="Full Name" className="w-full p-3 border border-gray-200 rounded-lg" />
              <input type="email" placeholder="Email" className="w-full p-3 border border-gray-200 rounded-lg" />
              <input type="password" placeholder="Password" className="w-full p-3 border border-gray-200 rounded-lg" />
              <button className="ios-button w-full">Create Account</button>
            </form>
            <p className="mt-4 text-center">
              Already have an account? 
              <button onClick={() => setCurrentPage('login')} className="text-blue-500 ml-1">Sign In</button>
            </p>
          </div>
        )}
      </div>
    );
  }

  const renderHome = () => (
    <div className="space-y-4">
      <div className="ios-card">
        <h2 className="text-lg font-medium mb-2">Your Balance</h2>
        <div className="text-3xl font-bold text-blue-600">{user.points || 0} points</div>
        <div className="ios-badge mt-2">{user.tier || 'Bronze'} Member</div>
      </div>
      
      <div className="ios-card">
        <h3 className="font-medium mb-3">Progress to Gold</h3>
        <div className="bg-gray-200 rounded-full h-2">
          <div className="bg-blue-500 h-2 rounded-full" style={{width: '60%'}}></div>
        </div>
        <p className="text-sm text-gray-600 mt-2">400 more points needed</p>
      </div>
    </div>
  );

  const renderRewards = () => (
    <div className="grid grid-cols-2 gap-4">
      {['Free Coffee', '10% Off', 'Free Pastry', 'Birthday Treat'].map((reward, i) => (
        <div key={i} className="ios-card">
          <h3 className="font-medium">{reward}</h3>
          <p className="text-blue-600 font-semibold">{(i + 1) * 100} points</p>
        </div>
      ))}
    </div>
  );

  const renderCard = () => (
    <div className="ios-card text-center">
      <h2 className="text-xl font-semibold mb-4">Member Card</h2>
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-6 rounded-lg text-white mb-4">
        <h3 className="text-lg font-medium">{user.name}</h3>
        <p className="text-sm opacity-90">Member ID: {user.id}</p>
      </div>
      <div className="w-32 h-32 bg-black mx-auto rounded-lg flex items-center justify-center">
        <span className="text-white text-xs">QR CODE</span>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="ios-card">
      <h2 className="text-xl font-semibold mb-4">Profile</h2>
      <div className="space-y-1">
        <div className="ios-list-row">
          <span>Name</span>
          <span>{user.name}</span>
        </div>
        <div className="ios-list-row">
          <span>Email</span>
          <span>{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span>Member Since</span>
          <span>Jan 2024</span>
        </div>
      </div>
      <button onClick={logout} className="ios-button w-full mt-6 bg-red-500">Sign Out</button>
    </div>
  );

  const getPageContent = () => {
    switch(currentPage) {
      case 'rewards': return renderRewards();
      case 'card': return renderCard();
      case 'profile': return renderProfile();
      default: return renderHome();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="ios-nav-bar">
        <h1 className="ios-nav-title-large">test15</h1>
      </div>
      
      <div className="p-4 pb-20">
        {getPageContent()}
      </div>

      <div className="ios-tab-bar">
        <div 
          className={`ios-tab-item ${currentPage === 'home' ? 'active' : ''}`}
          onClick={() => setCurrentPage('home')}
        >
          <span className="text-xl">🏠</span>
          <span>Home</span>
        </div>
        <div 
          className={`ios-tab-item ${currentPage === 'rewards' ? 'active' : ''}`}
          onClick={() => setCurrentPage('rewards')}
        >
          <span className="text-xl">🎁</span>
          <span>Rewards</span>
        </div>
        <div 
          className={`ios-tab-item ${currentPage === 'card' ? 'active' : ''}`}
          onClick={() => setCurrentPage('card')}
        >
          <span className="text-xl">💳</span>
          <span>Card</span>
        </div>
        <div 
          className={`ios-tab-item ${currentPage === 'profile' ? 'active' : ''}`}
          onClick={() => setCurrentPage('profile')}
        >
          <span className="text-xl">👤</span>
          <span>Profile</span>
        </div>
      </div>
    </div>
  );
}

export default App;