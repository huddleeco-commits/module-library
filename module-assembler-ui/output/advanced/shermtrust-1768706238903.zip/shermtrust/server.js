const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');
const authRoutes = require('./routes/auth');
const pointsRoutes = require('./routes/points');
const rewardsRoutes = require('./routes/rewards');
const adminRoutes = require('./routes/admin');
const qrRoutes = require('./routes/qr');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.use('/api/auth', authRoutes);
app.use('/api/points', pointsRoutes);
app.use('/api/rewards', rewardsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/qr', qrRoutes);

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({error: 'Internal server error'});
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});