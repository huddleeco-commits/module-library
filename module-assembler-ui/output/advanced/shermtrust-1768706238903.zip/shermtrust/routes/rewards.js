const express = require('express');
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

router.get('/list', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM rewards WHERE active = true ORDER BY cost ASC');
    res.json({ rewards: result.rows });
  } catch (error) {
    res.status(500).json({error: 'Failed to get rewards'});
  }
});

router.post('/redeem/:id', verifyToken, async (req, res) => {
  try {
    const rewardId = req.params.id;
    
    const rewardResult = await pool.query('SELECT * FROM rewards WHERE id = $1 AND active = true', [rewardId]);
    const reward = rewardResult.rows[0];
    
    if (!reward) {
      return res.status(404).json({error: 'Reward not found'});
    }
    
    const userResult = await pool.query('SELECT points FROM users WHERE id = $1', [req.user.userId]);
    const user = userResult.rows[0];
    
    if (user.points < reward.cost) {
      return res.status(400).json({error: 'Insufficient ShermCoins'});
    }
    
    const newBalance = user.points - reward.cost;
    
    await pool.query('UPDATE users SET points = $1 WHERE id = $2', [newBalance, req.user.userId]);
    
    await pool.query(
      'INSERT INTO point_transactions (user_id, type, amount, description) VALUES ($1, $2, $3, $4)',
      [req.user.userId, 'redeem', -reward.cost, `Redeemed: ${reward.name}`]
    );
    
    await pool.query(
      'INSERT INTO redemptions (user_id, reward_id, cost) VALUES ($1, $2, $3)',
      [req.user.userId, rewardId, reward.cost]
    );
    
    res.json({ 
      success: true, 
      reward: reward.name, 
      cost: reward.cost, 
      balance: newBalance 
    });
  } catch (error) {
    res.status(500).json({error: 'Failed to redeem reward'});
  }
});

module.exports = router;