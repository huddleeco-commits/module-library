const express = require('express');
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const getTierMultiplier = (tier) => {
  const tiers = { Bronze: 1, Silver: 1.25, Gold: 1.5, Platinum: 2 };
  return tiers[tier] || 1;
};

const updateTier = async (userId, points) => {
  let tier = 'Bronze';
  if (points >= 5000) tier = 'Platinum';
  else if (points >= 2000) tier = 'Gold';
  else if (points >= 500) tier = 'Silver';
  
  await pool.query('UPDATE users SET tier = $1 WHERE id = $2', [tier, userId]);
  return tier;
};

router.get('/balance', verifyToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT points, tier FROM users WHERE id = $1', [req.user.userId]);
    const user = result.rows[0];
    
    res.json({ balance: user.points, tier: user.tier });
  } catch (error) {
    res.status(500).json({error: 'Failed to get balance'});
  }
});

router.get('/history', verifyToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM point_transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
      [req.user.userId]
    );
    
    res.json({ transactions: result.rows });
  } catch (error) {
    res.status(500).json({error: 'Failed to get history'});
  }
});

router.post('/earn', verifyToken, async (req, res) => {
  try {
    const { amount, description } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({error: 'Invalid amount'});
    }
    
    const userResult = await pool.query('SELECT points, tier FROM users WHERE id = $1', [req.user.userId]);
    const user = userResult.rows[0];
    
    const multiplier = getTierMultiplier(user.tier);
    const earnedPoints = Math.floor(amount * multiplier);
    const newBalance = user.points + earnedPoints;
    
    await pool.query('UPDATE users SET points = $1 WHERE id = $2', [newBalance, req.user.userId]);
    
    await pool.query(
      'INSERT INTO point_transactions (user_id, type, amount, description) VALUES ($1, $2, $3, $4)',
      [req.user.userId, 'earn', earnedPoints, description || 'Points earned']
    );
    
    const newTier = await updateTier(req.user.userId, newBalance);
    
    res.json({ earned: earnedPoints, balance: newBalance, tier: newTier });
  } catch (error) {
    res.status(500).json({error: 'Failed to earn points'});
  }
});

router.post('/spend', verifyToken, async (req, res) => {
  try {
    const { amount, description } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({error: 'Invalid amount'});
    }
    
    const userResult = await pool.query('SELECT points FROM users WHERE id = $1', [req.user.userId]);
    const user = userResult.rows[0];
    
    if (user.points < amount) {
      return res.status(400).json({error: 'Insufficient ShermCoins'});
    }
    
    const newBalance = user.points - amount;
    
    await pool.query('UPDATE users SET points = $1 WHERE id = $2', [newBalance, req.user.userId]);
    
    await pool.query(
      'INSERT INTO point_transactions (user_id, type, amount, description) VALUES ($1, $2, $3, $4)',
      [req.user.userId, 'spend', -amount, description || 'Points spent']
    );
    
    const newTier = await updateTier(req.user.userId, newBalance);
    
    res.json({ spent: amount, balance: newBalance, tier: newTier });
  } catch (error) {
    res.status(500).json({error: 'Failed to spend points'});
  }
});

module.exports = router;