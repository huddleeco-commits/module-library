const express = require('express');
const QRCode = require('qrcode');
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

router.get('/member/:id', async (req, res) => {
  try {
    const userId = req.params.id;
    
    const userResult = await pool.query('SELECT id, name, tier FROM users WHERE id = $1', [userId]);
    const user = userResult.rows[0];
    
    if (!user) {
      return res.status(404).json({error: 'User not found'});
    }
    
    const qrData = JSON.stringify({
      userId: user.id,
      name: user.name,
      tier: user.tier,
      timestamp: Date.now()
    });
    
    const qrCode = await QRCode.toBuffer(qrData, { width: 300 });
    
    res.setHeader('Content-Type', 'image/png');
    res.send(qrCode);
  } catch (error) {
    res.status(500).json({error: 'Failed to generate QR code'});
  }
});

router.post('/scan', verifyToken, async (req, res) => {
  try {
    const { qrData } = req.body;
    
    if (!qrData) {
      return res.status(400).json({error: 'QR data required'});
    }
    
    const data = JSON.parse(qrData);
    const { userId, timestamp } = data;
    
    if (Date.now() - timestamp > 300000) {
      return res.status(400).json({error: 'QR code expired'});
    }
    
    const userResult = await pool.query(
      'SELECT id, name, email, points, tier FROM users WHERE id = $1',
      [userId]
    );
    const user = userResult.rows[0];
    
    if (!user) {
      return res.status(404).json({error: 'Invalid QR code'});
    }
    
    res.json({ valid: true, user });
  } catch (error) {
    res.status(400).json({error: 'Invalid QR code format'});
  }
});

module.exports = router;