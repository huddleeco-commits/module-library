import React, { useState } from 'react';

const Rewards = () => {
  const [showModal, setShowModal] = useState(false);
  const [selectedReward, setSelectedReward] = useState(null);

  const rewards = [
    { id: 1, title: '10% Off Next Purchase', cost: 100, description: 'Save on your next order' },
    { id: 2, title: 'Free Coffee', cost: 150, description: 'Any size coffee drink' },
    { id: 3, title: 'Free Shipping', cost: 75, description: 'Free delivery on any order' },
    { id: 4, title: '$5 Store Credit', cost: 250, description: 'Credit towards any purchase' },
    { id: 5, title: 'VIP Access', cost: 500, description: 'Early access to sales' },
    { id: 6, title: 'Gift Card $10', cost: 400, description: '$10 gift card' }
  ];

  const handleRedeem = (reward) => {
    setSelectedReward(reward);
    setShowModal(true);
  };

  const confirmRedeem = () => {
    setShowModal(false);
    setSelectedReward(null);
  };

  return (
    <div className="rewards-container">
      <div className="rewards-grid">
        {rewards.map(reward => (
          <div key={reward.id} className="ios-card">
            <h3>{reward.title}</h3>
            <p>{reward.description}</p>
            <div className="reward-cost">{reward.cost} ShermCoins</div>
            <button 
              className="ios-button-primary"
              onClick={() => handleRedeem(reward)}
            >
              Redeem
            </button>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="ios-modal-sheet" onClick={e => e.stopPropagation()}>
            <h2>Confirm Redemption</h2>
            <p>Redeem {selectedReward?.title} for {selectedReward?.cost} ShermCoins?</p>
            <div className="modal-actions">
              <button className="ios-button-primary" onClick={confirmRedeem}>
                Confirm
              </button>
              <button onClick={() => setShowModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rewards;