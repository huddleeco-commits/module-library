import React, { useState } from 'react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [searchTerm, setSearchTerm] = useState('');
  const [customers] = useState([
    { id: 1, name: 'John Doe', email: 'john@email.com', balance: 150, totalEarned: 500 },
    { id: 2, name: 'Jane Smith', email: 'jane@email.com', balance: 75, totalEarned: 300 },
    { id: 3, name: 'Bob Johnson', email: 'bob@email.com', balance: 220, totalEarned: 800 }
  ]);
  const [stats] = useState({
    totalCustomers: 3,
    totalCoinsIssued: 1600,
    totalCoinsRedeemed: 850,
    activeBalance: 445
  });

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddCoins = (e) => {
    e.preventDefault();
    console.log('Adding coins');
  };

  return (
    <div className="admin-panel">
      <h1>ShermCoin Admin Panel</h1>
      
      <div className="ios-segmented-control">
        <button 
          className={activeTab === 'customers' ? 'active' : ''}
          onClick={() => setActiveTab('customers')}
        >
          Customers
        </button>
        <button 
          className={activeTab === 'add-coins' ? 'active' : ''}
          onClick={() => setActiveTab('add-coins')}
        >
          Add ShermCoin
        </button>
        <button 
          className={activeTab === 'stats' ? 'active' : ''}
          onClick={() => setActiveTab('stats')}
        >
          Statistics
        </button>
      </div>

      {activeTab === 'customers' && (
        <div className="tab-content">
          <div className="ios-card">
            <h2>Customer Management</h2>
            <div className="ios-input">
              <input
                type="text"
                placeholder="Search customers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="customer-table">
              <div className="table-header ios-list-row">
                <span>Name</span>
                <span>Email</span>
                <span>Balance</span>
                <span>Total Earned</span>
                <span>Actions</span>
              </div>
              {filteredCustomers.map(customer => (
                <div key={customer.id} className="ios-list-row">
                  <span>{customer.name}</span>
                  <span>{customer.email}</span>
                  <span>{customer.balance} SC</span>
                  <span>{customer.totalEarned} SC</span>
                  <div>
                    <button className="ios-button-primary">Edit</button>
                    <button className="ios-button-primary">Add Coins</button>
                  </div>
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'add-coins' && (
        <div className="tab-content">
          <div className="ios-card">
            <h2>Add ShermCoins</h2>
            <form onSubmit={handleAddCoins}>
              <div className="ios-input">
                <label>Customer Email</label>
                <input type="email" placeholder="Enter customer email" required />
              </div>
              <div className="ios-input">
                <label>Amount</label>
                <input type="number" placeholder="Enter ShermCoin amount" min="1" required />
              </div>
              <div className="ios-input">
                <label>Reason</label>
                <select required>
                  <option value="">Select reason</option>
                  <option value="purchase">Purchase Reward</option>
                  <option value="bonus">Bonus</option>
                  <option value="referral">Referral</option>
                  <option value="promotion">Promotion</option>
                </select>
              </div>
              <div className="ios-input">
                <label>Notes (Optional)</label>
                <textarea placeholder="Additional notes" rows="3"></textarea>
              </div>
              <button type="submit" className="ios-button-primary">Add ShermCoins</button>
            </form>
          </div>
        </div>
      )}

      {activeTab === 'stats' && (
        <div className="tab-content">
          <div className="stats-grid">
            <div className="ios-card">
              <h3>Total Customers</h3>
              <div className="stat-value">{stats.totalCustomers}</div>
            </div>
            <div className="ios-card">
              <h3>Total ShermCoins Issued</h3>
              <div className="stat-value">{stats.totalCoinsIssued} SC</div>
            </div>
            <div className="ios-card">
              <h3>Total ShermCoins Redeemed</h3>
              <div className="stat-value">{stats.totalCoinsRedeemed} SC</div>
            </div>
            <div className="ios-card">
              <h3>Active Balance</h3>
              <div className="stat-value">{stats.activeBalance} SC</div>
            </div>
          </div>
          
          <div className="ios-card">
            <h2>Recent Activity</h2>
            <div className="activity-list">
              <div className="ios-list-row">
                <span>John Doe earned 25 SC - Purchase</span>
                <span>2 hours ago</span>
              </div>
              <div className="ios-list-row">
                <span>Jane Smith redeemed 50 SC - Coffee</span>
                <span>4 hours ago</span>
              </div>
              <div className="ios-list-row">
                <span>Bob Johnson earned 15 SC - Referral</span>
                <span>1 day ago</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;