import React from 'react';

const Profile = ({ user }) => {
  const handleShareReferral = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join ShermCoin',
        text: `Use my referral code: ${user.referralCode}`,
        url: window.location.origin
      });
    } else {
      navigator.clipboard.writeText(user.referralCode);
      alert('Referral code copied!');
    }
  };

  return (
    <div className="profile-page">
      <div className="ios-card">
        <div className="profile-header">
          <div className="avatar">
            <img src={user.avatar || '/default-avatar.png'} alt="Profile" />
          </div>
          <h2>{user.name}</h2>
          <div className="ios-badge tier-badge">{user.tier}</div>
        </div>
      </div>

      <div className="ios-card">
        <div className="ios-list-row">
          <span className="label">Email</span>
          <span className="value">{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Lifetime ShermCoin</span>
          <span className="value">{user.lifetimeShermCoin.toLocaleString()}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Referral Code</span>
          <span className="value">{user.referralCode}</span>
        </div>
      </div>

      <button className="ios-button" onClick={handleShareReferral}>
        Share Referral Code
      </button>
    </div>
  );
};

export default Profile;