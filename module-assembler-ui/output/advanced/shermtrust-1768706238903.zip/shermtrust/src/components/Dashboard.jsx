import React from 'react';

const Dashboard = ({ user }) => {
  const getTierColor = (tier) => {
    switch (tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const getNextTierThreshold = (tier) => {
    switch (tier) {
      case 'Bronze': return 1000;
      case 'Silver': return 2500;
      case 'Gold': return 5000;
      default: return 10000;
    }
  };

  const nextThreshold = getNextTierThreshold(user?.tier || 'Bronze');
  const progress = Math.min((user?.points || 0) / nextThreshold * 100, 100);

  return (
    <div style={{ padding: '20px' }}>
      <div className="ios-card" style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h1 style={{ fontSize: '48px', margin: '20px 0 10px' }}>
          {(user?.points || 0).toLocaleString()}
        </h1>
        <p style={{ fontSize: '18px', color: '#666', marginBottom: '20px' }}>ShermCoins</p>
        
        <div className="ios-badge" style={{ 
          backgroundColor: getTierColor(user?.tier || 'Bronze'),
          color: 'white',
          padding: '8px 16px',
          borderRadius: '20px',
          fontSize: '14px',
          fontWeight: 'bold',
          display: 'inline-block',
          marginBottom: '20px'
        }}>
          {user?.tier || 'Bronze'} Member
        </div>

        <div style={{ margin: '20px 0' }}>
          <p style={{ fontSize: '14px', color: '#666', marginBottom: '8px' }}>
            Progress to next tier: {user?.points || 0} / {nextThreshold}
          </p>
          <div style={{ 
            backgroundColor: '#E0E0E0',
            height: '8px',
            borderRadius: '4px',
            overflow: 'hidden'
          }}>
            <div style={{
              backgroundColor: getTierColor(user?.tier || 'Bronze'),
              height: '100%',
              width: `${progress}%`,
              transition: 'width 0.3s ease'
            }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;