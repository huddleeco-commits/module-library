import React from 'react';

const MemberCard = ({ user }) => {
  const getTierColor = (tier) => {
    switch (tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const generateQR = (userId) => {
    return `data:image/svg+xml;base64,${btoa(`
      <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="80" fill="white"/>
        <rect x="10" y="10" width="60" height="60" fill="black"/>
        <rect x="15" y="15" width="10" height="10" fill="white"/>
        <rect x="25" y="25" width="10" height="10" fill="white"/>
        <rect x="35" y="35" width="10" height="10" fill="white"/>
        <rect x="45" y="45" width="10" height="10" fill="white"/>
        <rect x="55" y="55" width="10" height="10" fill="white"/>
      </svg>
    `)}`;
  };

  return (
    <div style={{ padding: '20px' }}>
      <div className="ios-card" style={{ 
        background: `linear-gradient(135deg, ${getTierColor(user?.tier || 'Bronze')}, ${getTierColor(user?.tier || 'Bronze')}88)`,
        color: 'white',
        minHeight: '200px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <div style={{ 
          position: 'absolute',
          top: '20px',
          right: '20px',
          fontSize: '12px',
          fontWeight: 'bold'
        }}>
          SHERMCOIN
        </div>
        
        <div className="ios-badge" style={{ 
          backgroundColor: 'rgba(255,255,255,0.2)',
          color: 'white',
          padding: '6px 12px',
          borderRadius: '15px',
          fontSize: '12px',
          fontWeight: 'bold',
          display: 'inline-block',
          marginBottom: '30px',
          border: '1px solid rgba(255,255,255,0.3)'
        }}>
          {user?.tier || 'Bronze'} MEMBER
        </div>

        <div style={{ marginBottom: '20px' }}>
          <p style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '5px' }}>
            {user?.name || 'Member Name'}
          </p>
          <p style={{ fontSize: '14px', opacity: '0.9' }}>
            ID: {user?.id || '000000'}
          </p>
        </div>

        <div style={{ 
          position: 'absolute',
          bottom: '20px',
          right: '20px',
          backgroundColor: 'white',
          padding: '8px',
          borderRadius: '8px'
        }}>
          <img 
            src={generateQR(user?.id)} 
            alt="Member QR Code" 
            style={{ width: '60px', height: '60px' }}
          />
        </div>

        <div style={{ 
          position: 'absolute',
          bottom: '20px',
          left: '20px',
          fontSize: '16px',
          fontWeight: 'bold'
        }}>
          {(user?.points || 0).toLocaleString()} SC
        </div>
      </div>
    </div>
  );
};

export default MemberCard;