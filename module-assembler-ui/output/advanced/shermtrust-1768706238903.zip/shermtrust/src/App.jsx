import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';

function App() {
  const { user, login, register, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [registerForm, setRegisterForm] = useState({ name: '', email: '', password: '' });

  const handleLogin = async (e) => {
    e.preventDefault();
    await login(loginForm.email, loginForm.password);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    await register(registerForm.name, registerForm.email, registerForm.password);
  };

  const rewards = [
    { id: 1, name: 'Free Coffee', cost: 100, description: 'Redeem for any coffee' },
    { id: 2, name: '10% Off Purchase', cost: 150, description: 'Valid on next purchase' },
    { id: 3, name: 'Free Meal', cost: 500, description: 'Any meal up to $15' },
    { id: 4, name: 'VIP Access', cost: 1000, description: 'Exclusive member benefits' }
  ];

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-md mx-auto pt-20">
          {currentPage === 'login' ? (
            <div className="ios-card">
              <h2 className="text-2xl font-bold mb-6">Welcome Back</h2>
              <form onSubmit={handleLogin}>
                <div className="mb-4">
                  <input
                    type="email"
                    placeholder="Email"
                    className="w-full p-3 border border-gray-300 rounded-lg"
                    value={loginForm.email}
                    onChange={(e) => setLoginForm({...loginForm, email: e.target.value})}
                  />
                </div>
                <div className="mb-6">
                  <input
                    type="password"
                    placeholder="Password"
                    className="w-full p-3 border border-gray-300 rounded-lg"
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                  />
                </div>
                <button type="submit" className="ios-button w-full mb-4">Sign In</button>
                <button type="button" className="ios-button-outline w-full" onClick={() => setCurrentPage('register')}>Create Account</button>
              </form>
            </div>
          ) : (
            <div className="ios-card">
              <h2 className="text-2xl font-bold mb-6">Join ShermTrust</h2>
              <form onSubmit={handleRegister}>
                <div className="mb-4">
                  <input
                    type="text"
                    placeholder="Full Name"
                    className="w-full p-3 border border-gray-300 rounded-lg"
                    value={registerForm.name}
                    onChange={(e) => setRegisterForm({...registerForm, name: e.target.value})}
                  />
                </div>
                <div className="mb-4">
                  <input
                    type="email"
                    placeholder="Email"
                    className="w-full p-3 border border-gray-300 rounded-lg"
                    value={registerForm.email}
                    onChange={(e) => setRegisterForm({...registerForm, email: e.target.value})}
                  />
                </div>
                <div className="mb-6">
                  <input
                    type="password"
                    placeholder="Password"
                    className="w-full p-3 border border-gray-300 rounded-lg"
                    value={registerForm.password}
                    onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
                  />
                </div>
                <button type="submit" className="ios-button w-full mb-4">Create Account</button>
                <button type="button" className="ios-button-outline w-full" onClick={() => setCurrentPage('login')}>Sign In</button>
              </form>
            </div>
          )}
        </div>
      </div>
    );
  }

  const renderHome = () => (
    <div className="space-y-6">
      <div className="ios-card text-center">
        <h3 className="text-lg font-semibold mb-2">ShermCoin Balance</h3>
        <div className="text-4xl font-bold text-blue-600 mb-4">{user.points || 0}</div>
        <div className="ios-badge inline-block">{user.tier || 'Bronze'} Member</div>
      </div>
      <div className="ios-card">
        <h4 className="font-semibold mb-2">Progress to Silver</h4>
        <div className="bg-gray-200 rounded-full h-2 mb-2">
          <div className="bg-blue-500 h-2 rounded-full" style={{width: `${((user.points || 0) % 1000) / 10}%`}}></div>
        </div>
        <p className="text-sm text-gray-600">{1000 - ((user.points || 0) % 1000)} ShermCoins to next tier</p>
      </div>
    </div>
  );

  const renderRewards = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {rewards.map(reward => (
        <div key={reward.id} className="ios-card">
          <h4 className="font-semibold mb-2">{reward.name}</h4>
          <p className="text-sm text-gray-600 mb-3">{reward.description}</p>
          <div className="flex justify-between items-center">
            <span className="font-bold text-blue-600">{reward.cost} SC</span>
            <button className={`ios-button ${(user.points || 0) >= reward.cost ? '' : 'opacity-50 cursor-not-allowed'}`} disabled={(user.points || 0) < reward.cost}>Redeem</button>
          </div>
        </div>
      ))}
    </div>
  );

  const renderCard = () => (
    <div className="ios-card text-center">
      <h3 className="text-xl font-bold mb-4">Member Card</h3>
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 rounded-lg mb-4">
        <h4 className="text-lg font-semibold">{user.name}</h4>
        <p className="text-sm opacity-90">{user.tier || 'Bronze'} Member</p>
        <div className="mt-4 text-xs">ID: {user.id}</div>
      </div>
      <div className="bg-gray-100 w-32 h-32 mx-auto rounded-lg flex items-center justify-center">
        <span className="text-xs text-gray-500">QR Code</span>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="space-y-6">
      <div className="ios-card">
        <div className="ios-list-row">
          <span>Name</span>
          <span className="text-gray-600">{user.name}</span>
        </div>
        <div className="ios-list-row">
          <span>Email</span>
          <span className="text-gray-600">{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span>Member Since</span>
          <span className="text-gray-600">Jan 2024</span>
        </div>
        <div className="ios-list-row border-b-0">
          <span>Tier</span>
          <span className="ios-badge">{user.tier || 'Bronze'}</span>
        </div>
      </div>
      <button onClick={logout} className="ios-button w-full bg-red-500 hover:bg-red-600">Sign Out</button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <nav className="ios-nav-bar">
        <h1 className="ios-nav-title-large">{
          currentPage === 'home' ? 'ShermTrust' :
          currentPage === 'rewards' ? 'Rewards' :
          currentPage === 'card' ? 'Member Card' : 'Profile'
        }</h1>
      </nav>
      
      <main className="p-4 pt-28">
        <div className="max-w-2xl mx-auto">
          {currentPage === 'home' && renderHome()}
          {currentPage === 'rewards' && renderRewards()}
          {currentPage === 'card' && renderCard()}
          {currentPage === 'profile' && renderProfile()}
        </div>
      </main>

      <nav className="ios-tab-bar">
        <button className={`ios-tab-item ${currentPage === 'home' ? 'active' : ''}`} onClick={() => setCurrentPage('home')}>
          <span className="text-xl">🏠</span>
          <span>Home</span>
        </button>
        <button className={`ios-tab-item ${currentPage === 'rewards' ? 'active' : ''}`} onClick={() => setCurrentPage('rewards')}>
          <span className="text-xl">🎁</span>
          <span>Rewards</span>
        </button>
        <button className={`ios-tab-item ${currentPage === 'card' ? 'active' : ''}`} onClick={() => setCurrentPage('card')}>
          <span className="text-xl">💳</span>
          <span>Card</span>
        </button>
        <button className={`ios-tab-item ${currentPage === 'profile' ? 'active' : ''}`} onClick={() => setCurrentPage('profile')}>
          <span className="text-xl">👤</span>
          <span>Profile</span>
        </button>
      </nav>
    </div>
  );
}

export default App;