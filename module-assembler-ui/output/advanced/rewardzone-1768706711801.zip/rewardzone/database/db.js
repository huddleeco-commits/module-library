const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

const query = (text, params) => pool.query(text, params);

const initDB = async () => {
  try {
    await query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        points_balance INTEGER DEFAULT 0,
        tier VARCHAR(50) DEFAULT 'Bronze',
        is_admin BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    await query(`
      CREATE TABLE IF NOT EXISTS transactions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        type VARCHAR(50) NOT NULL,
        amount INTEGER NOT NULL,
        description TEXT,
        balance_after INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    await query(`
      CREATE TABLE IF NOT EXISTS rewards (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        points_cost INTEGER NOT NULL,
        category VARCHAR(100),
        available BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    await query(`
      CREATE TABLE IF NOT EXISTS redemptions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        reward_id INTEGER REFERENCES rewards(id),
        points_spent INTEGER NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    await query(`
      INSERT INTO rewards (name, description, points_cost, category) 
      SELECT * FROM (VALUES 
        ('Free Coffee', 'Complimentary coffee of your choice', 100, 'Beverages'),
        ('10% Discount', '10% off your next purchase', 250, 'Discounts'),
        ('Free Dessert', 'Any dessert from our menu', 300, 'Food'),
        ('20% Discount', '20% off your next purchase', 500, 'Discounts'),
        ('Free Lunch', 'Complimentary lunch meal', 800, 'Food'),
        ('VIP Experience', 'Priority service and exclusive offers', 1500, 'Premium')
      ) AS v(name, description, points_cost, category)
      WHERE NOT EXISTS (SELECT 1 FROM rewards LIMIT 1)
    `);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization failed:', error);
    throw error;
  }
};

module.exports = { query, initDB };}