import { useState } from 'react';

function History() {
  const [activeTab, setActiveTab] = useState('all');

  const transactions = [
    { id: 1, type: 'earned', amount: 50, description: 'Purchase at Store A', date: '2024-01-15' },
    { id: 2, type: 'spent', amount: -100, description: 'Redeemed Free Coffee', date: '2024-01-14' },
    { id: 3, type: 'earned', amount: 25, description: 'Review Bonus', date: '2024-01-13' },
    { id: 4, type: 'earned', amount: 75, description: 'Purchase at Store B', date: '2024-01-12' },
    { id: 5, type: 'spent', amount: -200, description: 'Redeemed 10% Discount', date: '2024-01-11' },
    { id: 6, type: 'earned', amount: 30, description: 'Referral Bonus', date: '2024-01-10' }
  ];

  const filteredTransactions = transactions.filter(t => {
    if (activeTab === 'earned') return t.type === 'earned';
    if (activeTab === 'spent') return t.type === 'spent';
    return true;
  });

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString();
  };

  return (
    <div className="history">
      <div className="ios-segmented-control">
        <button 
          className={activeTab === 'all' ? 'active' : ''}
          onClick={() => setActiveTab('all')}
        >
          All
        </button>
        <button 
          className={activeTab === 'earned' ? 'active' : ''}
          onClick={() => setActiveTab('earned')}
        >
          Earned
        </button>
        <button 
          className={activeTab === 'spent' ? 'active' : ''}
          onClick={() => setActiveTab('spent')}
        >
          Spent
        </button>
      </div>

      <div className="history-list">
        {filteredTransactions.map(transaction => (
          <div key={transaction.id} className="ios-list-row">
            <div className="transaction-icon">
              {transaction.type === 'earned' ? '📈' : '📉'}
            </div>
            <div className="transaction-details">
              <h4>{transaction.description}</h4>
              <p className="transaction-date">{formatDate(transaction.date)}</p>
            </div>
            <div className={`transaction-amount ${transaction.type}`}>
              {transaction.amount > 0 ? '+' : ''}{transaction.amount} points
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default History;