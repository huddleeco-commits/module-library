import React from 'react';

export default function Dashboard({ user }) {
  const getTierColor = (tier) => {
    switch (tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const getNextTierPoints = (tier) => {
    switch (tier) {
      case 'Bronze': return 1000;
      case 'Silver': return 2500;
      case 'Gold': return 5000;
      default: return 0;
    }
  };

  const nextTierPoints = getNextTierPoints(user.tier);
  const progress = nextTierPoints > 0 ? (user.points / nextTierPoints) * 100 : 100;

  return (
    <div className="ios-card">
      <div style={{ textAlign: 'center', marginBottom: '24px' }}>
        <h1 style={{ fontSize: '32px', margin: '0 0 8px 0' }}>Welcome Back!</h1>
        <p style={{ color: '#666', margin: '0' }}>Hi {user.name}</p>
      </div>
      
      <div style={{ textAlign: 'center', marginBottom: '24px' }}>
        <div style={{ fontSize: '48px', fontWeight: 'bold', margin: '0 0 8px 0' }}>
          {user.points.toLocaleString()}
        </div>
        <div style={{ color: '#666' }}>points</div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '24px' }}>
        <span className="ios-badge" style={{ backgroundColor: getTierColor(user.tier), color: 'white' }}>
          {user.tier}
        </span>
      </div>

      {nextTierPoints > 0 && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span>Progress to next tier</span>
            <span>{nextTierPoints - user.points} points to go</span>
          </div>
          <div style={{ width: '100%', height: '8px', backgroundColor: '#f0f0f0', borderRadius: '4px' }}>
            <div
              style={{
                width: `${Math.min(progress, 100)}%`,
                height: '100%',
                backgroundColor: getTierColor(user.tier),
                borderRadius: '4px',
                transition: 'width 0.3s ease'
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}