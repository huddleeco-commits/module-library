import React from 'react';

export default function MemberCard({ user }) {
  const getTierColor = (tier) => {
    switch (tier) {
      case 'Bronze': return '#CD7F32';
      case 'Silver': return '#C0C0C0';
      case 'Gold': return '#FFD700';
      case 'Platinum': return '#E5E4E2';
      default: return '#CD7F32';
    }
  };

  const generateQRCode = (userId) => {
    return `data:image/svg+xml;base64,${btoa(`
      <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="80" fill="white"/>
        <rect x="8" y="8" width="8" height="8" fill="black"/>
        <rect x="24" y="8" width="8" height="8" fill="black"/>
        <rect x="40" y="8" width="8" height="8" fill="black"/>
        <rect x="56" y="8" width="8" height="8" fill="black"/>
        <rect x="8" y="24" width="8" height="8" fill="black"/>
        <rect x="40" y="24" width="8" height="8" fill="black"/>
        <rect x="8" y="40" width="8" height="8" fill="black"/>
        <rect x="24" y="40" width="8" height="8" fill="black"/>
        <rect x="56" y="40" width="8" height="8" fill="black"/>
        <rect x="8" y="56" width="8" height="8" fill="black"/>
        <rect x="40" y="56" width="8" height="8" fill="black"/>
        <rect x="56" y="56" width="8" height="8" fill="black"/>
      </svg>
    `)}`;
  };

  return (
    <div
      className="ios-card"
      style={{
        background: `linear-gradient(135deg, ${getTierColor(user.tier)}22, ${getTierColor(user.tier)}44)`,
        border: `2px solid ${getTierColor(user.tier)}`,
        color: '#333'
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '24px' }}>
        <div>
          <h3 style={{ margin: '0 0 4px 0', fontSize: '18px' }}>Member Card</h3>
          <span className="ios-badge" style={{ backgroundColor: getTierColor(user.tier), color: 'white' }}>
            {user.tier}
          </span>
        </div>
        <img
          src={generateQRCode(user.id)}
          alt="QR Code"
          style={{ width: '60px', height: '60px', borderRadius: '4px' }}
        />
      </div>
      
      <div style={{ marginBottom: '16px' }}>
        <div style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '4px' }}>
          {user.name}
        </div>
        <div style={{ color: '#666', fontSize: '14px' }}>
          Member since {new Date(user.createdAt).getFullYear()}
        </div>
      </div>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: '24px', fontWeight: 'bold' }}>
            {user.points.toLocaleString()}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>points</div>
        </div>
        <div style={{ color: '#666', fontSize: '12px' }}>
          ID: {user.id.toString().padStart(6, '0')}
        </div>
      </div>
    </div>
  );
}