import React, { useState, useEffect } from 'react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [pointsToAdd, setPointsToAdd] = useState('');
  const [stats, setStats] = useState({ totalCustomers: 0, totalPoints: 0, avgPoints: 0 });

  useEffect(() => {
    fetchCustomers();
    fetchStats();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await fetch('/api/customers');
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error('Failed to fetch customers');
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Failed to fetch stats');
    }
  };

  const addPoints = async (e) => {
    e.preventDefault();
    try {
      await fetch('/api/add-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId: selectedCustomer, points: parseInt(pointsToAdd) })
      });
      setPointsToAdd('');
      setSelectedCustomer('');
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Failed to add points');
    }
  };

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="admin-panel">
      <div className="ios-segmented-control">
        <button 
          className={activeTab === 'customers' ? 'active' : ''}
          onClick={() => setActiveTab('customers')}
        >
          Customers
        </button>
        <button 
          className={activeTab === 'addpoints' ? 'active' : ''}
          onClick={() => setActiveTab('addpoints')}
        >
          Add Points
        </button>
        <button 
          className={activeTab === 'stats' ? 'active' : ''}
          onClick={() => setActiveTab('stats')}
        >
          Statistics
        </button>
      </div>

      {activeTab === 'customers' && (
        <div className="ios-card">
          <h2>Customer Management</h2>
          <input 
            type="text" 
            className="ios-input"
            placeholder="Search customers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="customer-list">
            {filteredCustomers.map(customer => (
              <div key={customer.id} className="ios-list-row">
                <div className="customer-info">
                  <span className="customer-name">{customer.name}</span>
                  <span className="customer-email">{customer.email}</span>
                </div>
                <div className="customer-points">
                  <span className="points-badge">{customer.points} points</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'addpoints' && (
        <div className="ios-card">
          <h2>Add Points to Customer</h2>
          <form onSubmit={addPoints}>
            <select 
              className="ios-input"
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
              required
            >
              <option value="">Select Customer</option>
              {customers.map(customer => (
                <option key={customer.id} value={customer.id}>
                  {customer.name} - {customer.email}
                </option>
              ))}
            </select>
            <input 
              type="number" 
              className="ios-input"
              placeholder="Points to add"
              value={pointsToAdd}
              onChange={(e) => setPointsToAdd(e.target.value)}
              required
              min="1"
            />
            <button type="submit" className="ios-button ios-button-primary">
              Add Points
            </button>
          </form>
        </div>
      )}

      {activeTab === 'stats' && (
        <div className="ios-card">
          <h2>Loyalty Program Statistics</h2>
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-label">Total Customers</span>
              <span className="stat-value">{stats.totalCustomers}</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Total Points Issued</span>
              <span className="stat-value">{stats.totalPoints}</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Average Points per Customer</span>
              <span className="stat-value">{Math.round(stats.avgPoints)}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;