import React, { useState } from 'react';

const Profile = () => {
  const [user] = useState({
    name: 'John Doe',
    email: 'john.doe@example.com',
    tier: 'Gold',
    lifetimePoints: 2450,
    referralCode: 'JOHN2024'
  });

  const handleShareReferral = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join me and earn points!',
        text: `Use my referral code: ${user.referralCode}`,
        url: window.location.origin
      });
    } else {
      navigator.clipboard.writeText(user.referralCode);
      alert('Referral code copied to clipboard!');
    }
  };

  return (
    <div className="profile-page">
      <div className="ios-card">
        <div className="profile-header">
          <div className="avatar">
            <img src="/api/placeholder/80/80" alt="Profile" />
          </div>
          <h2>{user.name}</h2>
          <span className="ios-badge tier-badge">{user.tier}</span>
        </div>
      </div>

      <div className="ios-card">
        <div className="ios-list-row">
          <span className="label">Email</span>
          <span className="value">{user.email}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Tier Status</span>
          <span className="ios-badge">{user.tier}</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Lifetime Points</span>
          <span className="value">{user.lifetimePoints.toLocaleString()} points</span>
        </div>
        <div className="ios-list-row">
          <span className="label">Referral Code</span>
          <span className="value referral-code">{user.referralCode}</span>
        </div>
      </div>

      <div className="ios-card">
        <button className="ios-button share-button" onClick={handleShareReferral}>
          Share Referral Code
        </button>
      </div>
    </div>
  );
};

export default Profile;