import { useState } from 'react';

function Rewards() {
  const [selectedReward, setSelectedReward] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const rewards = [
    { id: 1, name: 'Free Coffee', points: 100, image: '☕' },
    { id: 2, name: '10% Discount', points: 200, image: '🏷️' },
    { id: 3, name: 'Free Dessert', points: 150, image: '🧁' },
    { id: 4, name: 'Free Lunch', points: 500, image: '🍽️' },
    { id: 5, name: 'VIP Membership', points: 1000, image: '👑' },
    { id: 6, name: 'Gift Card $10', points: 750, image: '💳' }
  ];

  const handleRedeem = (reward) => {
    setSelectedReward(reward);
    setShowModal(true);
  };

  const confirmRedeem = () => {
    setShowModal(false);
    setSelectedReward(null);
  };

  return (
    <div className="rewards">
      <div className="rewards-grid">
        {rewards.map(reward => (
          <div key={reward.id} className="ios-card reward-card">
            <div className="reward-image">{reward.image}</div>
            <h3>{reward.name}</h3>
            <p>{reward.points} points</p>
            <button 
              className="ios-button-primary"
              onClick={() => handleRedeem(reward)}
            >
              Redeem
            </button>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="ios-modal-sheet" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Confirm Redemption</h2>
            </div>
            <div className="modal-content">
              <div className="reward-preview">
                <span className="reward-emoji">{selectedReward?.image}</span>
                <h3>{selectedReward?.name}</h3>
                <p>{selectedReward?.points} points</p>
              </div>
              <p>Are you sure you want to redeem this reward?</p>
            </div>
            <div className="modal-actions">
              <button className="ios-button-primary" onClick={confirmRedeem}>
                Confirm
              </button>
              <button className="cancel-button" onClick={() => setShowModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Rewards;