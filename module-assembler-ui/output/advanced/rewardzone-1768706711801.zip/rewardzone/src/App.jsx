import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';

function App() {
  const { user, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');

  const mockRewards = [
    { id: 1, name: '10% Off Coffee', cost: 100, description: 'Valid for any beverage' },
    { id: 2, name: 'Free Pastry', cost: 200, description: 'Choose any pastry' },
    { id: 3, name: '$5 Store Credit', cost: 500, description: 'Apply to any purchase' },
    { id: 4, name: 'VIP Experience', cost: 1000, description: 'Exclusive member benefits' }
  ];

  const LoginPage = () => (
    <div className="p-4">
      <div className="ios-card">
        <h2 className="text-2xl font-semibold mb-6">Welcome to RewardZone</h2>
        <div className="space-y-4">
          <input type="email" placeholder="Email" className="ios-input" />
          <input type="password" placeholder="Password" className="ios-input" />
          <button className="ios-button-primary w-full">Sign In</button>
        </div>
        <p className="text-center mt-4">
          Don't have an account?
          <button className="text-blue-500 ml-1" onClick={() => setCurrentPage('register')}>Sign Up</button>
        </p>
      </div>
    </div>
  );

  const RegisterPage = () => (
    <div className="p-4">
      <div className="ios-card">
        <h2 className="text-2xl font-semibold mb-6">Join RewardZone</h2>
        <div className="space-y-4">
          <input type="text" placeholder="Full Name" className="ios-input" />
          <input type="email" placeholder="Email" className="ios-input" />
          <input type="password" placeholder="Password" className="ios-input" />
          <button className="ios-button-primary w-full">Create Account</button>
        </div>
        <p className="text-center mt-4">
          Already have an account?
          <button className="text-blue-500 ml-1" onClick={() => setCurrentPage('login')}>Sign In</button>
        </p>
      </div>
    </div>
  );

  const HomePage = () => (
    <div className="p-4 space-y-6">
      <div className="ios-card text-center">
        <h3 className="text-lg font-medium text-gray-600">Your Points Balance</h3>
        <div className="text-4xl font-bold text-blue-600 my-2">{user?.points || 750}</div>
        <div className="ios-badge">Gold Member</div>
      </div>
      <div className="ios-card">
        <h4 className="font-medium mb-3">Progress to Platinum</h4>
        <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
          <div className="bg-blue-500 h-3 rounded-full" style={{width: '75%'}}></div>
        </div>
        <p className="text-sm text-gray-600">250 more points to unlock Platinum benefits</p>
      </div>
    </div>
  );

  const RewardsPage = () => (
    <div className="p-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {mockRewards.map(reward => (
          <div key={reward.id} className="ios-card">
            <h4 className="font-semibold">{reward.name}</h4>
            <p className="text-gray-600 text-sm my-2">{reward.description}</p>
            <div className="flex justify-between items-center">
              <span className="font-medium text-blue-600">{reward.cost} points</span>
              <button className="ios-button text-sm px-4 py-2">Redeem</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const CardPage = () => (
    <div className="p-4">
      <div className="ios-card text-center">
        <h3 className="text-xl font-semibold mb-4">Member Card</h3>
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 rounded-xl mx-4">
          <div className="text-lg font-medium">{user?.name || 'John Doe'}</div>
          <div className="text-sm opacity-90 mt-1">Gold Member</div>
          <div className="mt-4 bg-white p-4 rounded-lg">
            <div className="text-black text-xs">QR CODE</div>
            <div className="text-black text-xs mt-1">Member ID: #{user?.id || '12345'}</div>
          </div>
        </div>
      </div>
    </div>
  );

  const ProfilePage = () => (
    <div className="p-4 space-y-4">
      <div className="ios-card">
        <div className="ios-list-row">
          <span>Account Settings</span>
          <span className="text-gray-400">›</span>
        </div>
        <div className="ios-list-row">
          <span>Notification Preferences</span>
          <span className="text-gray-400">›</span>
        </div>
        <div className="ios-list-row">
          <span>Transaction History</span>
          <span className="text-gray-400">›</span>
        </div>
        <div className="ios-list-row">
          <span>Help & Support</span>
          <span className="text-gray-400">›</span>
        </div>
      </div>
      <button className="ios-button w-full" onClick={logout}>Sign Out</button>
    </div>
  );

  const renderContent = () => {
    if (!user) {
      return currentPage === 'register' ? <RegisterPage /> : <LoginPage />;
    }
    
    switch (currentPage) {
      case 'rewards': return <RewardsPage />;
      case 'card': return <CardPage />;
      case 'profile': return <ProfilePage />;
      default: return <HomePage />;
    }
  };

  const getPageTitle = () => {
    if (!user) return currentPage === 'register' ? 'Sign Up' : 'Sign In';
    switch (currentPage) {
      case 'rewards': return 'Rewards';
      case 'card': return 'My Card';
      case 'profile': return 'Profile';
      default: return 'RewardZone';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="ios-nav-bar">
        <h1 className="ios-nav-title-large">{getPageTitle()}</h1>
      </nav>
      
      <main className="pb-20">
        {renderContent()}
      </main>
      
      {user && (
        <nav className="ios-tab-bar">
          <button 
            className={`ios-tab-item ${currentPage === 'home' ? 'active' : ''}`}
            onClick={() => setCurrentPage('home')}
          >
            <div className="w-6 h-6 mx-auto mb-1">🏠</div>
            <span>Home</span>
          </button>
          <button 
            className={`ios-tab-item ${currentPage === 'rewards' ? 'active' : ''}`}
            onClick={() => setCurrentPage('rewards')}
          >
            <div className="w-6 h-6 mx-auto mb-1">🎁</div>
            <span>Rewards</span>
          </button>
          <button 
            className={`ios-tab-item ${currentPage === 'card' ? 'active' : ''}`}
            onClick={() => setCurrentPage('card')}
          >
            <div className="w-6 h-6 mx-auto mb-1">💳</div>
            <span>Card</span>
          </button>
          <button 
            className={`ios-tab-item ${currentPage === 'profile' ? 'active' : ''}`}
            onClick={() => setCurrentPage('profile')}
          >
            <div className="w-6 h-6 mx-auto mb-1">👤</div>
            <span>Profile</span>
          </button>
        </nav>
      )}
    </div>
  );
}

export default App;