const express = require('express');
const db = require('../database/db');
const { verifyToken } = require('../middleware/auth');
const router = express.Router();

router.get('/list', async (req, res) => {
  try {
    const result = await db.query(
      'SELECT id, name, description, points_cost, category, available FROM rewards WHERE available = true ORDER BY points_cost'
    );
    
    res.json(result.rows);
  } catch (error) {
    res.status(400).json({ error: 'Failed to get rewards' });
  }
});

router.post('/redeem/:id', verifyToken, async (req, res) => {
  try {
    const rewardId = parseInt(req.params.id);
    
    if (!rewardId) {
      return res.status(400).json({ error: 'Invalid reward ID' });
    }
    
    const rewardResult = await db.query(
      'SELECT id, name, points_cost, available FROM rewards WHERE id = $1',
      [rewardId]
    );
    
    if (rewardResult.rows.length === 0) {
      return res.status(400).json({ error: 'Reward not found' });
    }
    
    const reward = rewardResult.rows[0];
    
    if (!reward.available) {
      return res.status(400).json({ error: 'Reward not available' });
    }
    
    const userResult = await db.query(
      'SELECT points_balance FROM users WHERE id = $1',
      [req.userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    
    if (user.points_balance < reward.points_cost) {
      return res.status(400).json({ error: 'Insufficient points' });
    }
    
    const newBalance = user.points_balance - reward.points_cost;
    
    await db.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, req.userId]
    );
    
    await db.query(
      'INSERT INTO transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [req.userId, 'redeem', reward.points_cost, `Redeemed: ${reward.name}`, newBalance]
    );
    
    await db.query(
      'INSERT INTO redemptions (user_id, reward_id, points_spent, status) VALUES ($1, $2, $3, $4)',
      [req.userId, rewardId, reward.points_cost, 'pending']
    );
    
    res.json({ 
      message: 'Reward redeemed successfully',
      reward: reward.name,
      pointsSpent: reward.points_cost,
      newBalance
    });
  } catch (error) {
    res.status(400).json({ error: 'Failed to redeem reward' });
  }
});

module.exports = router;