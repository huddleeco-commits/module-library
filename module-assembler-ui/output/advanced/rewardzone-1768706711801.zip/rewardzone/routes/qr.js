const express = require('express');
const QRCode = require('qrcode');
const db = require('../database/db');
const { verifyToken } = require('../middleware/auth');
const router = express.Router();

router.get('/member/:id', async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    
    if (!userId) {
      return res.status(400).json({ error: 'Invalid user ID' });
    }
    
    const userResult = await db.query(
      'SELECT id, name, tier FROM users WHERE id = $1 AND is_admin = false',
      [userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const qrData = JSON.stringify({
      userId: userId,
      name: userResult.rows[0].name,
      tier: userResult.rows[0].tier,
      timestamp: Date.now()
    });
    
    const qrCodeImage = await QRCode.toBuffer(qrData, {
      type: 'png',
      width: 300,
      margin: 2
    });
    
    res.setHeader('Content-Type', 'image/png');
    res.send(qrCodeImage);
  } catch (error) {
    res.status(400).json({ error: 'Failed to generate QR code' });
  }
});

router.post('/scan', verifyToken, async (req, res) => {
  try {
    const { qrData } = req.body;
    
    if (!qrData) {
      return res.status(400).json({ error: 'QR data required' });
    }
    
    let memberData;
    try {
      memberData = JSON.parse(qrData);
    } catch {
      return res.status(400).json({ error: 'Invalid QR code' });
    }
    
    if (!memberData.userId || !memberData.timestamp) {
      return res.status(400).json({ error: 'Invalid QR code format' });
    }
    
    const hoursDiff = (Date.now() - memberData.timestamp) / (1000 * 60 * 60);
    if (hoursDiff > 24) {
      return res.status(400).json({ error: 'QR code expired' });
    }
    
    const userResult = await db.query(
      'SELECT id, name, email, points_balance, tier FROM users WHERE id = $1 AND is_admin = false',
      [memberData.userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'Member not found' });
    }
    
    res.json({
      valid: true,
      member: userResult.rows[0],
      scannedAt: new Date().toISOString()
    });
  } catch (error) {
    res.status(400).json({ error: 'Failed to scan QR code' });
  }
});

module.exports = router;