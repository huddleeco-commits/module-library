const express = require('express');
const db = require('../database/db');
const { verifyToken } = require('../middleware/auth');
const router = express.Router();

const calculateTierMultiplier = (tier) => {
  const multipliers = { Bronze: 1, Silver: 1.25, Gold: 1.5, Platinum: 2 };
  return multipliers[tier] || 1;
};

const updateUserTier = async (userId, points) => {
  let tier = 'Bronze';
  if (points >= 5000) tier = 'Platinum';
  else if (points >= 2000) tier = 'Gold';
  else if (points >= 500) tier = 'Silver';
  
  await db.query('UPDATE users SET tier = $1 WHERE id = $2', [tier, userId]);
  return tier;
};

router.get('/balance', verifyToken, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT points_balance, tier FROM users WHERE id = $1',
      [req.userId]
    );
    
    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(400).json({ error: 'Failed to get balance' });
  }
});

router.get('/history', verifyToken, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT * FROM transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
      [req.userId]
    );
    
    res.json(result.rows);
  } catch (error) {
    res.status(400).json({ error: 'Failed to get history' });
  }
});

router.post('/earn', verifyToken, async (req, res) => {
  try {
    const { amount, description = 'Points earned' } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }
    
    const userResult = await db.query(
      'SELECT points_balance, tier FROM users WHERE id = $1',
      [req.userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    const multiplier = calculateTierMultiplier(user.tier);
    const earnedPoints = Math.floor(amount * multiplier);
    const newBalance = user.points_balance + earnedPoints;
    
    await db.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, req.userId]
    );
    
    await db.query(
      'INSERT INTO transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [req.userId, 'earn', earnedPoints, description, newBalance]
    );
    
    const newTier = await updateUserTier(req.userId, newBalance);
    
    res.json({ 
      points: earnedPoints,
      balance: newBalance,
      tier: newTier,
      multiplier
    });
  } catch (error) {
    res.status(400).json({ error: 'Failed to earn points' });
  }
});

router.post('/spend', verifyToken, async (req, res) => {
  try {
    const { amount, description = 'Points spent' } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }
    
    const userResult = await db.query(
      'SELECT points_balance FROM users WHERE id = $1',
      [req.userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    
    if (user.points_balance < amount) {
      return res.status(400).json({ error: 'Insufficient points' });
    }
    
    const newBalance = user.points_balance - amount;
    
    await db.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, req.userId]
    );
    
    await db.query(
      'INSERT INTO transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [req.userId, 'spend', amount, description, newBalance]
    );
    
    const newTier = await updateUserTier(req.userId, newBalance);
    
    res.json({ 
      spent: amount,
      balance: newBalance,
      tier: newTier
    });
  } catch (error) {
    res.status(400).json({ error: 'Failed to spend points' });
  }
});

module.exports = router;