const express = require('express');
const db = require('../database/db');
const { verifyToken, requireAdmin } = require('../middleware/auth');
const router = express.Router();

router.get('/customers', verifyToken, requireAdmin, async (req, res) => {
  try {
    const result = await db.query(
      'SELECT id, email, name, points_balance, tier, created_at FROM users WHERE is_admin = false ORDER BY created_at DESC'
    );
    
    res.json(result.rows);
  } catch (error) {
    res.status(400).json({ error: 'Failed to get customers' });
  }
});

router.get('/stats', verifyToken, requireAdmin, async (req, res) => {
  try {
    const totalUsers = await db.query('SELECT COUNT(*) as count FROM users WHERE is_admin = false');
    const totalPoints = await db.query('SELECT SUM(points_balance) as total FROM users WHERE is_admin = false');
    const tierCounts = await db.query('SELECT tier, COUNT(*) as count FROM users WHERE is_admin = false GROUP BY tier');
    const recentTransactions = await db.query(
      'SELECT COUNT(*) as count FROM transactions WHERE created_at >= NOW() - INTERVAL \'30 days\''
    );
    
    res.json({
      totalUsers: parseInt(totalUsers.rows[0].count),
      totalPointsIssued: parseInt(totalPoints.rows[0].total) || 0,
      tierDistribution: tierCounts.rows,
      recentTransactions: parseInt(recentTransactions.rows[0].count)
    });
  } catch (error) {
    res.status(400).json({ error: 'Failed to get stats' });
  }
});

router.post('/:id/points', verifyToken, requireAdmin, async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    const { amount, type, description } = req.body;
    
    if (!userId || !amount || !type) {
      return res.status(400).json({ error: 'User ID, amount, and type required' });
    }
    
    if (type !== 'earn' && type !== 'spend') {
      return res.status(400).json({ error: 'Type must be earn or spend' });
    }
    
    const userResult = await db.query(
      'SELECT points_balance FROM users WHERE id = $1 AND is_admin = false',
      [userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(400).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    let newBalance;
    
    if (type === 'earn') {
      newBalance = user.points_balance + Math.abs(amount);
    } else {
      if (user.points_balance < Math.abs(amount)) {
        return res.status(400).json({ error: 'Insufficient points' });
      }
      newBalance = user.points_balance - Math.abs(amount);
    }
    
    await db.query(
      'UPDATE users SET points_balance = $1 WHERE id = $2',
      [newBalance, userId]
    );
    
    await db.query(
      'INSERT INTO transactions (user_id, type, amount, description, balance_after) VALUES ($1, $2, $3, $4, $5)',
      [userId, type, Math.abs(amount), description || `Admin ${type}`, newBalance]
    );
    
    res.json({ 
      message: 'Points updated successfully',
      newBalance,
      type,
      amount: Math.abs(amount)
    });
  } catch (error) {
    res.status(400).json({ error: 'Failed to update points' });
  }
});

module.exports = router;